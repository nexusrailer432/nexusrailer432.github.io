# NOVA

NOVA is a beginner-friendly programming language designed around one idea:
**programming that feels like texting.**

It aims to lower the barrier to learning programming while staying
structured and predictable. Actions read like short instructions, and
expressions keep the familiar shape of maths:

```nova
ask "What's your name?" and remember answer as name
say "Hello " + name

remember my prices as [3, 5, 8]
say "Total: " + (prices[0] + prices[1] + prices[2])
```

NOVA is a small language with a complete, tested implementation. It is not
a replacement for Python or any other language, and it is not trying to be
one. It is a first language: something you can read on day one and still
use to build a real, working program.

**Version 1.0.0**

---

## Contents

- [Installing and running](#installing-and-running)
- [Your first program](#your-first-program)
- [Syntax basics](#syntax-basics)
- [Values](#values)
- [Variables](#variables)
- [Input](#input)
- [Output](#output)
- [Numbers and maths](#numbers-and-maths)
- [Text](#text)
- [true and false](#true-and-false)
- [Conditions](#conditions)
- [Loops](#loops)
- [Functions](#functions)
- [Lists](#lists)
- [Files](#files)
- [Line breaks: newline](#line-breaks-newline)
- [Understanding errors](#understanding-errors)
- [Examples](#examples)
- [Project structure](#project-structure)
- [Running the tests](#running-the-tests)
- [What NOVA does not have](#what-nova-does-not-have)
- [Contributing](#contributing)
- [License](#license)
- [Status](#status)

---

## Installing and running

NOVA needs **Python 3.10 or newer** and nothing else. There are no
dependencies to install.

1. Download or clone this folder.
2. Open a terminal inside it.
3. Run a program:

```
python nova.py examples/01_hello.nova
```

On macOS and Linux you may need `python3` instead of `python`.

Useful commands:

```
python nova.py --version      show the version
python nova.py --help         show how to use NOVA
```

A NOVA program is a plain text file ending in `.nova`. Write it in any
text editor.

## Your first program

Create a file called `hello.nova`:

```nova
say "Hello world!"
```

Run it:

```
python nova.py hello.nova
```

You should see:

```
Hello world!
```

## Syntax basics

- One instruction per line.
- Blank lines are ignored.
- A line starting with `#` is a note for people, and NOVA skips it.
- Indentation is optional. NOVA uses `done` to end a block, not spacing,
  but indenting makes programs much easier to read.
- Keywords work in any capitalisation: `say`, `SAY`, and `Say` are the same.
- Names are also case-insensitive: `name` and `NAME` are one value.

## Values

NOVA has four kinds of values:

| Kind | Examples |
|------|----------|
| text | `"Alex"`, `"Hello world"`, `""` |
| number | `15`, `-8`, `3.14` |
| true/false | `true`, `false` |
| list | `["Apple", 15, [1, 2]]` |

A value keeps its kind. NOVA never quietly turns one kind into another, so
the number `18` and the text `"18"` are different values.

## Variables

`remember` gives a value a name:

```nova
remember my name as Alex
remember my age as 15
remember my prices as [3, 5, 8]
say name
```

Simple text doesn't need quotes, so `remember my name as Alex` stores the
text `Alex`. Quotes are needed when the text contains something NOVA would
otherwise read as an instruction, and for text with leading or trailing
spaces.

Remembering a name again replaces the value.

To give an existing value a second name, use `copy`:

```nova
remember my price as 10
copy price as backup
say backup
```

This matters: `remember my backup as price` stores the *word* `price`, not
the value `10`. `copy` is the way to duplicate a value.

## Input

`ask` shows a question and keeps what the person types:

```nova
ask "What's your name?" and remember answer as name
say "Hello " + name
```

If the answer must be a number, add `as a number`. NOVA keeps asking until
it gets one:

```nova
ask "How old are you?" and remember answer as age as a number
say "Next year you'll be " + (age + 1)
```

Without `as a number`, something typed as `15` still becomes the number 15,
but `hello` stays text. Values with leading zeros, like `007`, stay text so
codes and phone numbers survive.

## Output

`say` prints one line:

```nova
say "Hello"
say name
say 2 + 3
say ["a", "b"]
```

## Numbers and maths

```nova
say 2 + 3
say 10 - 4
say 3 * 5
say 10 / 4
```

That prints `5`, `6`, `15`, and `2.5`.

The same operations can be written as words:

```nova
say 10 plus 5
say 20 minus 3
say 4 times 5
say 20 divided by 4
```

Multiplication and division happen before addition and subtraction, and
brackets work as usual:

```nova
say 2 + 3 * 4
say (2 + 3) * 4
say -10 + 3
```

Those print `14`, `20`, and `-7`.

Whole results are shown without a trailing `.0`, so `4 / 2` shows `2`.
Long decimals are shown to ten places: `1 / 3` gives `0.3333333333`.

Dividing by zero stops the program with a clear message rather than a
strange number.

## Text

Text is written in double quotes. Join text with `+`:

```nova
say "Hello " + "world"
say "Age: " + 15
```

When `+` has a number on both sides it adds. If either side is text, it
joins, turning the other value into text. Joining happens left to right,
so brackets matter:

```nova
say "Total: " + 1 + 2
say "Total: " + (1 + 2)
```

The first prints `Total: 12`, the second `Total: 3`.

NOVA does not use backslash escape codes: `"a\nb"` is the four characters
`a`, `\`, `n`, `b`. See [newline](#line-breaks-newline) for line breaks.

## true and false

`true` and `false` answer yes/no questions, and `file exists` gives one
back:

```nova
remember my ready as true
say ready

if ready is true
    say "Let's go"
done
```

They can be stored, passed to functions, returned, put in lists, joined
into text, and compared with `is` and `is not`. They are not numbers, so
`true` is not `1`, and they cannot be added or ordered.

## Conditions

```nova
remember my age as 20

if age is 18 or more
    say "Adult"
otherwise
    say "Minor"
done
```

Every `if` ends with `done`. The `otherwise` part is optional.

Ways to compare:

| Form | Meaning |
|------|---------|
| `x is y` | equal |
| `x is not y` | not equal |
| `x is greater than y` | bigger (also `is above`) |
| `x is less than y` | smaller (also `is below`) |
| `x is y or more` | bigger or equal |
| `x is y or less` | smaller or equal |

Numbers compare with numbers and text compares with text. Text comparison
is alphabetical and equality is exact, so `"Alex"` is not `"alex"`. Lists
are equal when they hold equal items in the same order; they can't be put
in order with `greater than`.

An `if` checks one thing. To check two, put one `if` inside another.

## Loops

Repeat a fixed number of times:

```nova
repeat 3 times
    say "Hello"
done
```

The count can be any expression that gives a whole number, including
`length of items`. Zero or fewer means the block doesn't run.

Repeat while something stays true:

```nova
remember my count as 1

while count is 5 or less
    say count
    remember my count as count + 1
done
```

The question is checked again before every round, so something inside the
loop has to change it. Every loop ends with `done`.

## Functions

`define` names steps you can use again:

```nova
define greet(name)
    say "Hello " + name
done

greet("Alex")
```

`return` gives a value back:

```nova
define square(x)
    return x * x
done

say square(5)
```

- Inputs are called parameters; the values you pass in are arguments.
- Each call gets its own variables. A function can read values from the
  main program, but anything it remembers stays inside the function.
- Functions can call other functions, including themselves.
- A function can be used before the line that defines it.

## Lists

A list holds values in order:

```nova
remember my fruits as ["Apple", "Banana", "Mango"]
say fruits
say length of fruits
```

Positions start at 0:

```nova
say fruits[0]
say fruits[2]
```

That prints `Apple` and then `Mango`.

Changing a list:

```nova
set fruits[0] as "Orange"
add "Grapes" to fruits
remove fruits[1]
```

Lists can hold any values, including other lists:

```nova
remember my grid as [[1, 2], [3, 4]]
say grid[0][1]
```

That prints `2`.

Lists are values, not shared boxes. Copying a list or passing it to a
function gives that name its own copy, so changing one never changes the
other:

```nova
remember my a as [1, 2]
copy a as b
add 3 to b
say a
say b
```

That prints `[1, 2]` and then `[1, 2, 3]`.

Going past the end of a list, or using a negative or fractional position,
stops the program with a message saying which positions are valid.

## Files

NOVA reads and writes plain text files, always as UTF-8.

```nova
write "Shopping list:" + newline to "notes.txt"
append "Milk" + newline to "notes.txt"
say read "notes.txt"

if file exists "notes.txt"
    say "The file is there."
done
```

- `write text to path` replaces the whole file, creating it if needed.
- `append text to path` adds to the end, creating it if needed.
- `read path` gives the whole file back as text.
- `file exists path` gives `true` or `false`. A folder is not a file.

The text and the path can be any expression. Text goes in and comes out
exactly as stored: nothing is trimmed and no separators are added.

A plain name like `"notes.txt"` means a file in the folder you ran NOVA
from, not the folder the program is saved in. Subfolders, `./`, `../`, and
full paths all work. NOVA does not create folders.

NOVA has the same file permissions as the person running it, and there is
no sandbox, so run programs you trust. A file's contents are only ever
text: NOVA never runs what it reads.

## Line breaks: newline

`newline` is a built-in text value holding exactly one line break:

```nova
write "First" + newline + "Second" to "notes.txt"
say "Hello" + newline + "World"
```

It is ordinary text, so it works anywhere text works. NOVA does not use
backslash escapes, so `newline` is how line breaks are written.

## Understanding errors

NOVA checks a whole program before running any of it, so mistakes in
spelling and structure are reported before anything happens, even inside
parts that would never run.

An error names the line, shows it, explains the problem, and usually
suggests a fix:

```
NOVA error on line 4:
    say fruits[5]
  fruits has 3 items, so the index must be from 0 to 2, but it was 5.
  Hint: The first item is fruits[0].
```

Some problems can only be found while running, because they depend on real
values: a missing file, a list position that turns out to be too big,
dividing by zero, or using a name before it has a value. Those stop the
program at the line where they happen and explain what went wrong.

Press Ctrl+C to stop a running program.

## Examples

The `examples/` folder has ten numbered programs that build up in order:

| File | Covers |
|------|--------|
| `01_hello.nova` | printing text |
| `02_variables.nova` | remembering and copying values |
| `03_input.nova` | asking questions, numeric answers |
| `04_calculator.nova` | arithmetic, brackets, precedence |
| `05_conditions.nova` | if, otherwise, nesting, comparisons |
| `06_loops.nova` | repeat and while |
| `07_functions.nova` | define, return, functions calling functions |
| `08_lists.nova` | making, reading, changing and walking lists |
| `09_files.nova` | write, append, read, file exists, newline |
| `10_quiz.nova` | a complete program using all of the above |

Run one with:

```
python nova.py examples/01_hello.nova
```

The other files in `examples/` are smaller programs that each demonstrate
one feature; they are also used as tests.

Programs in `examples/` that write files use names starting with
`nova_demo_`, so they cannot overwrite anything of yours.

## Project structure

```
nova.py              the command you run
novalang/            the interpreter
  __init__.py        version and public API
  cli.py             the command line
  errors.py          error messages and suggestions
  runtime.py         program structure and execution
  validation.py      checks a program before it runs
  blocks.py          if, repeat, while
  commands.py        say, remember, ask, copy, set, add, remove, write, append, return
  conditions.py      comparisons
  functions.py       define, calls, scope
  expressions.py     working out values
  parser.py          expressions into a tree
  tokenizer.py       text into tokens
  values.py          the four kinds of value
  lists.py           list positions and length
  files.py           reading and writing files
examples/            programs to learn from
tests/               the test suite
```

NOVA runs a program in four steps: read the structure, register the
functions, check the whole program, then run it.

## Running the tests

From this folder:

```
python -m unittest
```

For more detail:

```
python -m unittest -v
```

The suite covers the language, the command line, the examples, the
documentation, and a security check that the interpreter never runs
arbitrary code. Tests that touch files use temporary folders and leave
nothing behind.

## What NOVA does not have

NOVA 1.0 is deliberately small. It does not have classes or objects,
modules or imports, exceptions, `for` loops, `break` or `continue`,
dictionaries, text positions or text length, general `and`/`or` in
conditions, networking, or a package manager.

Some of these may arrive later. NOVA 1.0 is meant to be learnable in an
afternoon, and every feature above is fully implemented and tested rather
than partly working.

## Contributing

NOVA is small on purpose, so the most useful contributions are:

- clear bug reports, with the shortest NOVA program that shows the problem
- better error messages
- more example programs
- documentation that explains an idea more clearly

If you change the interpreter, run `python -m unittest` first; every change
should keep the whole suite passing and add a test for the behaviour it
changes. New language features need a design discussion before code.

## License

Not yet decided. Until a license is chosen, treat this as source-available
for learning and evaluation.

## Status

NOVA 1.0.0 is the first stable release. The language is frozen: programs
written against 1.0 are meant to keep working.

Known limits of this release, recorded honestly rather than hidden:

- There is no installer yet. NOVA is run with `python nova.py program.nova`.
  A standalone `nova` command is future work.
- There is no way to turn text into a number, so a number read from a file
  comes back as text. `examples/10_quiz.nova` shows a workaround.
- `ask` takes a question written in quotes, not a value worked out while
  running.
- Text has no length and no positions, so lists are the way to work through
  items one at a time.
