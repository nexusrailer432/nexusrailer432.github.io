#!/usr/bin/env python3
"""
NOVA command-line entry point.

Usage:  python nova.py examples/hello.nova

The interpreter itself lives in the novalang/ package.
"""

import sys

from novalang.cli import main

if __name__ == "__main__":
    sys.exit(main(sys.argv))
