"""
Block types: if, repeat, while. (define lives in functions.py.)

Every block has:
  header     the text after its keyword ("age is 18", "5 times", "count is 3 or less")
  body       the lines inside it (an if also has an otherwise_body)
  prepare()  parses the header once and caches it
  run()      a generator the runtime drives: it yields the lines to run
             next, and may also yield function-call requests while working
             out its header (if check(age) is "Adult")

The runtime (runtime.py) never needs to know how a block works inside:
it just asks each block for its lines. Adding a new block type means
adding a class here and one entry in BLOCK_TYPES.

prepare() is separate from run() on purpose: a future "check the whole
program before running" pass can call prepare() on every block, including
blocks inside branches that never run.
"""

from dataclasses import dataclass, field

from .commands import STATEMENT_WORDS, parse_call_line, parse_command
from .conditions import evaluate_condition, parse_condition
from .errors import NovaError, UnknownNameError
from .expressions import evaluate_steps, text_in_math_hint, too_deep_error
from .parser import parse_expression
from .tokenizer import is_word, tokenize
from .values import describe, format_number, is_number


@dataclass
class CommandLine:
    """A line that starts with a command word:  say "Hi" """
    line_number: int
    text: str
    command: object = None  # the parsed command, filled in by validate()

    def validate(self, function_names):
        self.command = parse_command(self.text, function_names)

    def expressions(self):
        return self.command.expressions()

    def assigned_names(self):
        return getattr(self.command, "assigned_names", set)()


@dataclass
class CallLine:
    """A line that is just a function call:  greet("Alex")"""
    line_number: int
    text: str
    command: object = None

    def validate(self, function_names):
        self.command = parse_call_line(self.text)

    def expressions(self):
        return self.command.expressions()

    def assigned_names(self):
        return set()


@dataclass
class Block:
    line_number: int
    text: str
    header: str
    body: list = field(default_factory=list)
    parsed_header: object = None

    keyword = "block"          # overridden by each block type
    description = "block"      # for messages: "a repeat loop can't have an otherwise"

    def prepare(self):
        """Parse the header the first time it's needed, then reuse it."""
        if self.parsed_header is None:
            self.parsed_header = self.parse_header(self.header)
        return self.parsed_header

    def validate(self, function_names):
        self.prepare()

    def expressions(self):
        """The expression trees in this block's header (for checking calls)."""
        header = self.prepare()
        if hasattr(header, "left"):  # a condition
            return [header.left, header.right]
        return [header]

    def assigned_names(self):
        return set()


# ---------------------------------------------------------------------------
# if
# ---------------------------------------------------------------------------

@dataclass
class IfBlock(Block):
    otherwise_body: list = field(default_factory=list)
    otherwise_line: int = None

    keyword = "if"
    description = "if"

    def parse_header(self, header):
        return parse_condition(header, "if")

    def run(self, variables, loop_limit):
        condition = self.prepare()
        holds = yield from evaluate_condition(condition, variables)
        for node in (self.body if holds else self.otherwise_body):
            yield node


# ---------------------------------------------------------------------------
# repeat
# ---------------------------------------------------------------------------

REPEAT_USAGE = "repeat 5 times"
NUMBER_WORDS = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
    "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12,
    "twenty": 20, "fifty": 50, "hundred": 100,
}
REPEAT_WORDS = {"once": 1, "twice": 2, "thrice": 3}


def parse_repeat_header(header):
    """'2 + 3 times' -> expression tree for 2 + 3"""
    tokens = tokenize(header)
    last = tokens[-1] if tokens else None

    if is_word(last, *REPEAT_WORDS):
        number = REPEAT_WORDS[last.value.lower()]
        raise NovaError(f"NOVA doesn't understand '{last.value}' in a repeat line.",
                        hint=f"Write it with a number and 'times', like: repeat {number} times")
    if not is_word(last, "times"):
        if any(is_word(token, "times") for token in tokens):
            raise NovaError("Nothing can come after 'times' in a repeat line.",
                            hint="Put the commands on the lines below, and end with done.")
        raise NovaError("A repeat line must end with the word 'times'.",
                        hint=f"For example: {REPEAT_USAGE}")

    count_tokens = tokens[:-1]
    if not count_tokens:
        raise NovaError("Say how many times to repeat.", hint=f"For example: {REPEAT_USAGE}")
    if any(is_word(token, *STATEMENT_WORDS) for token in count_tokens):
        raise NovaError("A repeat line holds only the count.",
                        hint="Put commands on the lines below the repeat, and end with done.")
    try:
        return parse_expression(count_tokens)
    except RecursionError:
        raise too_deep_error() from None


def repeat_count(tree, variables):
    """
    Work out how many rounds a repeat runs (use with 'yield from').
      numbers only; no text is converted
      whole numbers only; 2.5 is an error, never silently cut to 2
      zero or negative -> zero rounds
    """
    try:
        value = yield from evaluate_steps(tree, variables)
    except UnknownNameError as error:
        word = error.name.lower()
        if word in NUMBER_WORDS:
            error.hint = f"Write the number with digits, like: repeat {NUMBER_WORDS[word]} times"
        raise

    if not is_number(value):
        raise NovaError(f"The repeat count must be a number, but it's {describe(value)}.",
                        hint=text_in_math_hint(value) + f" For example: {REPEAT_USAGE}")
    if isinstance(value, float):  # whole floats were already turned into ints
        raise NovaError("Repeat count must be a whole number.",
                        hint=f"I got {format_number(value)}. Use a whole number, like 2 or 3.")
    return max(value, 0)


@dataclass
class RepeatBlock(Block):
    keyword = "repeat"
    description = "repeat loop"

    def parse_header(self, header):
        return parse_repeat_header(header)

    def run(self, variables, loop_limit):
        count = yield from repeat_count(self.prepare(), variables)  # worked out once
        if loop_limit is not None and count > loop_limit:
            raise NovaError(
                f"This repeat asks for {count:,} rounds, but this run allows at most {loop_limit:,}.",
                hint="Use a smaller number, or run without a loop limit.")
        for _ in range(count):
            for node in self.body:
                yield node


# ---------------------------------------------------------------------------
# while
# ---------------------------------------------------------------------------

@dataclass
class WhileBlock(Block):
    keyword = "while"
    description = "while loop"

    def parse_header(self, header):
        return parse_condition(header, "while")

    def run(self, variables, loop_limit):
        condition = self.prepare()  # header mistakes are reported before the first round
        count = 0  # this loop's own round count; function calls never reset it
        while (yield from evaluate_condition(condition, variables)):  # re-checked every round
            count += 1
            if loop_limit is not None and count > loop_limit:
                raise NovaError(
                    f"This while loop has run {loop_limit:,} times and still hasn't stopped.",
                    hint="Make sure something inside the loop changes the condition, "
                         "so it can become false.")
            for node in self.body:
                yield node


# Line-starting keywords that open a block.
BLOCK_TYPES = {"if": IfBlock, "repeat": RepeatBlock, "while": WhileBlock}

# What to say when a block keyword has nothing after it.
EMPTY_HEADER_ERRORS = {
    "if": ("'if' needs something to check.", "For example: if age is 18 or more"),
    "while": ("'while' needs something to check.", "For example: while count is 5 or less"),
    "repeat": ("'repeat' needs a number and the word 'times'.", f"For example: {REPEAT_USAGE}"),
}
