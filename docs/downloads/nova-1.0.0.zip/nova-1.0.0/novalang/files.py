"""
Files: NOVA's small text-file API.

  read "notes.txt"                  an expression: the file's text
  file exists "notes.txt"           an expression: true or false
  write "Hi" to "notes.txt"         a command: replace the file's text
  append "more" to "notes.txt"      a command: add to the end of the file

Rules:
  - Text files only, always UTF-8.
  - Text goes in and comes out exactly as stored: no line endings are
    changed, nothing is stripped, and no separators are added.
  - Paths are text. Relative paths are relative to the folder NOVA was
    started from (the current working directory), not the program's folder.
  - There is no sandbox: NOVA can open any file the person running it can.

Everything that touches the disk is in this module, and every file is
opened with 'with', so it is closed even when something goes wrong.
Nothing here runs a program, a shell, or file contents.
"""

import errno
import os

from .errors import NovaError
from .values import describe, is_list, is_text, to_text

ENCODING = "utf-8"


def path_text(value, action):
    """A file path must be non-empty text."""
    if not is_text(value):
        hint = 'Paths are text in quotes, like: "notes.txt"'
        if is_list(value) and action in ("write", "append"):
            hint = 'To put an item in a list, use: add "Grape" to fruits. ' + hint
        raise NovaError(f"A file path must be text, but this one is {describe(value)}.", hint=hint)
    if value == "":
        raise NovaError("A file path can't be empty.", hint='For example: "notes.txt"')
    return value


def file_error(error, path, action):
    """Turn an operating-system error into a friendly NovaError."""
    verb = {"read": "read", "write": "write to", "append": "add to"}[action]
    subject = f'I couldn\'t {verb} "{path}"'
    if isinstance(error, FileNotFoundError):
        if action == "read":
            return NovaError(f"{subject} because the file does not exist.",
                             hint="Check the filename, or create the file first with write.")
        return NovaError(f"{subject} because its folder does not exist.",
                         hint="Check the folder part of the path. NOVA can't create folders.")
    if isinstance(error, IsADirectoryError) or (
            isinstance(error, PermissionError) and os.path.isdir(path)):
        return NovaError(f"{subject} because it is a folder, not a file.",
                         hint="Add a file name to the path, like: \"notes/today.txt\"")
    if isinstance(error, NotADirectoryError):
        return NovaError(f"{subject} because part of the path is a file, not a folder.",
                         hint="Check each part of the path before the last /.")
    if isinstance(error, PermissionError):
        return NovaError(f"{subject} because permission was denied.",
                         hint="Choose a file you are allowed to change, or check its permissions.")
    if isinstance(error, (ValueError, UnicodeEncodeError)) or getattr(error, "errno", None) in (
            errno.EINVAL, errno.ENAMETOOLONG):
        return NovaError(f'"{path}" isn\'t a path this computer can use.',
                         hint="Try a simple name made of letters, numbers, and dots, like: \"notes.txt\"")
    reason = getattr(error, "strerror", None) or "the system refused"
    return NovaError(f"{subject} ({reason}).",
                     hint="Check the path, the disk, and the file's permissions.")


def read_file(path_value):
    path = path_text(path_value, "read")
    try:
        with open(path, "rb") as file:  # read bytes, then decode strictly, so binary files are caught
            data = file.read()
        if b"\x00" in data:
            raise NovaError(f'I couldn\'t read "{path}" because it isn\'t text.',
                            hint="NOVA reads text files. This looks like a picture, a program, "
                                 "or another kind of file.")
        return data.decode(ENCODING)  # newline bytes are kept exactly as stored
    except UnicodeDecodeError:
        raise NovaError(f'I couldn\'t read "{path}" because it isn\'t UTF-8 text.',
                        hint="NOVA reads text files. Save it as UTF-8, or check that it isn't "
                             "a picture or other non-text file.") from None
    except (OSError, ValueError) as error:
        raise file_error(error, path, "read") from None


def put_file(content_value, path_value, action):
    """write (mode "w", replace) or append (mode "a", add to the end; creates the file if needed)."""
    path = path_text(path_value, action)
    text = to_text(content_value)  # numbers, lists, true/false are written as 'say' shows them
    try:
        with open(path, "w" if action == "write" else "a", encoding=ENCODING, newline="") as file:
            file.write(text)
    except (OSError, ValueError, UnicodeEncodeError) as error:
        raise file_error(error, path, action) from None


def file_exists(path_value):
    """true only for an existing regular file (a folder is not a file)."""
    path = path_text(path_value, "check")
    try:
        return os.path.isfile(path)
    except (OSError, ValueError):  # a path the system can't use can't be an existing file
        return False
