"""
Validation: check the whole program before anything runs.

    PARSE -> REGISTER DEFINITIONS -> VALIDATE -> EXECUTE
    (runtime.parse_program)          (here)     (runtime.execute)

Nothing is executed and no value is worked out here. Every line is checked,
including lines in branches that will never be taken, loops that run zero
times, and functions that are never called.

Step 1, syntax. Every command line, call line, and block header is parsed
exactly once, in source order, so the first mistake in the file is the one
reported. The parsed result is kept on the line and reused every time the
line runs; nothing is parsed again during execution.

Step 2, calls. Every function call inside every expression is checked
against the program's function table: the function must exist, and it
must receive the right number of arguments. If the program uses a name as
a variable somewhere (remember, ask, copy, or a parameter), calling that
name with ( ) is explained as "a remembered value, not a function".

Things that depend on values (does this variable exist yet? is this count
a whole number? is the divisor zero?) can only be known while running,
so they stay runtime checks.
"""

from .errors import NovaError
from .expressions import calls_in
from .functions import check_call


def validate_program(program, variable_names=()):
    """Raise the first NovaError found in the program, or return quietly."""
    function_names = set(program.functions)

    for line in program.lines:  # step 1: syntax, in source order
        try:
            line.validate(function_names)
        except NovaError as error:
            raise error.at_line(line.line_number, line.text)

    remembered = {name.lower() for name in variable_names}
    for line in program.lines:
        remembered |= line.assigned_names()
    for function in program.functions.values():
        remembered |= {param.lower() for param in function.params}

    for line in program.lines:  # step 2: calls, in source order
        for tree in line.expressions():
            for call in calls_in(tree):
                try:
                    check_call(call.name, len(call.args), program.functions, remembered)
                except NovaError as error:
                    raise error.at_line(line.line_number, line.text)
