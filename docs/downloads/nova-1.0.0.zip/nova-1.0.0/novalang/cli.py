"""The NOVA command line: nova program.nova"""

import os
import sys

from . import VERSION
from .errors import NovaError
from .runtime import run_program

USAGE = """NOVA {version} - programming that feels like texting

Usage:
  nova <file.nova>     run a NOVA program
  nova --version       show the version
  nova --help          show this message

Example:
  nova examples/01_hello.nova

NOVA programs are plain text files ending in .nova.
Documentation: see README.md"""

HELP_FLAGS = ("--help", "-h", "help")
VERSION_FLAGS = ("--version", "-v", "version")


def read_source(path):
    """Read a .nova file and return its text."""
    if not path.lower().endswith(".nova"):
        raise NovaError(f"'{path}' is not a .nova file.",
                        hint="NOVA programs end in .nova, like hello.nova")
    try:
        # utf-8-sig quietly handles files saved by Windows Notepad
        with open(path, "r", encoding="utf-8-sig") as file:
            return file.read()
    except FileNotFoundError:
        raise NovaError(f"I couldn't find the file '{path}'.",
                        hint="Check the spelling and that you're in the right folder.") from None
    except IsADirectoryError:
        raise NovaError(f"'{path}' is a folder, not a file.") from None
    except PermissionError:
        raise NovaError(f"I'm not allowed to open '{path}'.",
                        hint="Check the file's permissions.") from None
    except UnicodeDecodeError:
        raise NovaError(f"I couldn't read '{path}'.",
                        hint="Save the file as UTF-8 text.") from None
    except OSError as error:
        reason = getattr(error, "strerror", None) or "the system refused"
        raise NovaError(f"I couldn't open '{path}' ({reason}).") from None


def usage(stream, code):
    print(USAGE.format(version=VERSION), file=stream)
    return code


def main(argv):
    """
    Exit codes:
      0   the program finished
      1   NOVA reported a problem: a mistake in the program, a missing file,
          or a command line it couldn't use
      130 stopped with Ctrl+C
      141 output was closed early (for example: nova x.nova | head)
    """
    arguments = argv[1:]
    if any(arg.lower() in HELP_FLAGS for arg in arguments):
        return usage(sys.stdout, 0)
    if any(arg.lower() in VERSION_FLAGS for arg in arguments):
        print(f"NOVA {VERSION}")
        return 0
    if not arguments:
        print("NOVA needs a program to run.\n", file=sys.stderr)
        return usage(sys.stderr, 1)
    if len(arguments) > 1:
        print(f"NOVA runs one program at a time, but got {len(arguments)} file names.\n",
              file=sys.stderr)
        return usage(sys.stderr, 1)

    try:
        run_program(read_source(arguments[0]))
    except NovaError as error:
        print(error, file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nProgram stopped.", file=sys.stderr)
        return 130
    except BrokenPipeError:
        # The output was piped into something that stopped reading early
        # (like: nova program.nova | head). Stop quietly, as other
        # command-line tools do. Pointing stdout at devnull stops Python
        # from complaining again while it shuts down.
        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        return 141
    return 0
