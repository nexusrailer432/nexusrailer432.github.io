"""
Expression parser: tokens -> expression tree.

Grammar (standard math precedence, left to right within a level):
  sum      := product (("+" | "-") product)*
  product  := unary   (("*" | "/") unary)*
  unary    := "-" unary | postfix
  postfix  := primary ("[" sum "]")*                 indexing: items[0], grid[0][1]
  primary  := NUMBER | TEXT | NAME | call | list | length | read | exists | boolean | "(" sum ")"
  call     := NAME "(" [sum ("," sum)*] ")"
  list     := "[" [sum ("," sum)*] "]"
  length   := "length" "of" postfix                  only when "of" follows "length"
  read     := "read" postfix                         only when text or a name follows "read"
  exists   := "file" "exists" postfix                only when "exists" follows "file"
  boolean  := "true" | "false"
  newline  := "newline"                              text: one LF character

Word operators (plus, minus, times, divided by) are only operators when
they sit where an operator is expected. Anywhere else they're ordinary names.
"""

from dataclasses import dataclass

from .errors import NovaError
from .values import NEWLINE, format_boolean, format_number, is_number


@dataclass
class Literal:
    value: object


@dataclass
class NameRef:
    name: str


@dataclass
class Negate:
    operand: object


@dataclass
class BinaryOp:
    symbol: str    # + - * /
    written: str   # how the user wrote it: "+", "plus", "divided by"
    left: object
    right: object


@dataclass
class Call:
    name: str      # as written
    args: list     # expression trees, evaluated left to right


@dataclass
class ListLiteral:
    items: list    # expression trees, evaluated left to right


@dataclass
class Index:
    target: object  # the list expression
    index: object   # the index expression


@dataclass
class Length:
    target: object  # length of <target>


@dataclass
class FileRead:
    path: object    # read <path>


@dataclass
class FileExists:
    path: object    # file exists <path>


# Words that keep their maths meaning after a name, so "read" is only a file
# read when something else follows it:  read plus 1  still adds to a variable.
OPERATOR_WORDS = ("plus", "minus", "times", "divided")


WORD_OPERATORS = {"plus": "+", "minus": "-", "times": "*"}  # "divided by" is two words


def render_expression(node):
    """Write an expression tree back as NOVA text, for error messages: grid[row]"""
    try:
        return _render(node)
    except RecursionError:
        return "this value"


def _render(node):
    if isinstance(node, Literal):
        if isinstance(node.value, bool):
            return format_boolean(node.value)
        if node.value == NEWLINE:
            return "newline"
        return format_number(node.value) if is_number(node.value) else f'"{node.value}"'
    if isinstance(node, NameRef):
        return node.name
    if isinstance(node, Call):
        return f"{node.name}({', '.join(_render(arg) for arg in node.args)})"
    if isinstance(node, ListLiteral):
        return "[" + ", ".join(_render(item) for item in node.items) + "]"
    if isinstance(node, Index):
        return f"{_render(node.target)}[{_render(node.index)}]"
    if isinstance(node, Length):
        return f"length of {_render(node.target)}"
    if isinstance(node, FileRead):
        return f"read {_render(node.path)}"
    if isinstance(node, FileExists):
        return f"file exists {_render(node.path)}"
    if isinstance(node, Negate):
        return "-" + _grouped(node.operand)
    if isinstance(node, BinaryOp):
        return f"{_grouped(node.left)} {node.written} {_grouped(node.right)}"
    return "this value"


def _grouped(node):
    return f"({_render(node)})" if isinstance(node, BinaryOp) else _render(node)


def parse_expression(tokens):
    """Parse a complete list of tokens into one expression tree."""
    return Parser(tokens).parse()


class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self, offset=0):
        index = self.pos + offset
        return self.tokens[index] if index < len(self.tokens) else None

    def parse(self):
        if not self.tokens:
            raise NovaError("There's nothing here to use.",
                            hint='Add a number, a name, or some text in quotes, like "Hello".')
        tree = self.parse_sum()
        leftover = self.peek()
        if leftover is not None:
            if leftover.kind == "RPAREN":
                raise NovaError("I found a ) without a matching (.",
                                hint="Every ) needs a ( before it.")
            if leftover.kind == "RBRACKET":
                raise NovaError("I found a ] without a matching [.",
                                hint="Every ] needs a [ before it.")
            if leftover.kind == "COMMA":
                raise NovaError("A comma can only separate the values inside a function call.",
                                hint='To join text, use +, like: say "a" + "b"')
            raise NovaError(
                "Two values are sitting next to each other with nothing joining them.",
                hint='Use + to join them, like "Hi " + name')
        return tree

    def match_operator(self, allowed):
        """If the next token(s) form an operator in `allowed`, consume them."""
        token = self.peek()
        if token is None:
            return None
        width = 1
        if token.kind == "OP":
            symbol, written = token.value, token.value
        elif token.kind == "NAME" and token.value.lower() in WORD_OPERATORS:
            symbol, written = WORD_OPERATORS[token.value.lower()], token.value
        elif token.kind == "NAME" and token.value.lower() == "divided":
            after = self.peek(1)
            if after is None or after.kind != "NAME" or after.value.lower() != "by":
                raise NovaError("I found 'divided' without 'by' after it.",
                                hint="Write it as: 20 divided by 4")
            symbol, written, width = "/", f"{token.value} {after.value}", 2
        else:
            return None
        if symbol not in allowed:
            return None
        self.pos += width
        return symbol, written

    def parse_right_side(self, written, parse_next):
        if self.peek() is None:
            raise NovaError(f"This line ends with {written} but nothing comes after it.",
                            hint=f"Add a value after {written}, like 10 {written} 5")
        return parse_next()

    def parse_sum(self):
        tree = self.parse_product()
        while (operator := self.match_operator({"+", "-"})):
            symbol, written = operator
            right = self.parse_right_side(written, self.parse_product)
            tree = BinaryOp(symbol, written, tree, right)
        return tree

    def parse_product(self):
        tree = self.parse_unary()
        while (operator := self.match_operator({"*", "/"})):
            symbol, written = operator
            right = self.parse_right_side(written, self.parse_unary)
            tree = BinaryOp(symbol, written, tree, right)
        return tree

    def parse_unary(self):
        token = self.peek()
        if token is not None and token.kind == "OP" and token.value == "-":
            self.pos += 1
            return Negate(self.parse_right_side("-", self.parse_unary))
        return self.parse_postfix()

    def parse_postfix(self):
        """A value, then any number of [index] parts: items[0], grid[0][1], make_list()[0]"""
        tree = self.parse_primary()
        while self.peek() is not None and self.peek().kind == "LBRACKET":
            tree = self.parse_index(tree)
        return tree

    def parse_index(self, target):
        where = render_expression(target)
        self.pos += 1  # skip "["
        missing_close = NovaError(f"The index after {where} is missing its closing ].",
                                  hint=f"For example: {where}[0]")
        if self.peek() is None:
            raise missing_close
        if self.peek().kind == "RBRACKET":
            raise NovaError(f"The brackets after {where} are empty.",
                            hint=f"Put an index inside them, like: {where}[0]")
        index = self.parse_sum()
        closing = self.peek()
        if closing is None:
            raise missing_close
        if closing.kind == "COMMA":
            raise NovaError("An index can only hold one number.",
                            hint=f"To reach inside a nested list, use one pair of brackets "
                                 f"per step, like: {where}[0][1]")
        if closing.kind == "RPAREN":
            raise NovaError("I found a ) where the index's closing ] was expected.",
                            hint=f"For example: {where}[0]")
        if closing.kind != "RBRACKET":
            raise NovaError(
                "Two values are sitting next to each other with nothing joining them.",
                hint='Use + to join them, like "Hi " + name')
        self.pos += 1  # skip "]"
        return Index(target, index)

    def parse_primary(self):
        token = self.peek()
        if token is None:
            raise NovaError("This expression stops too early.",
                            hint="Something is missing at the end of the line.")
        if token.kind in ("NUMBER", "TEXT"):
            self.pos += 1
            return Literal(token.value)
        if token.kind == "NAME":
            self.pos += 1
            following = self.peek()
            word = token.value.lower()
            if (word == "length" and following is not None
                    and following.kind == "NAME" and following.value.lower() == "of"):
                return self.parse_length()
            if word == "read" and self.reading_a_file(following):
                if following is None:
                    raise NovaError("Say which file to read after 'read'.",
                                    hint='For example: read "notes.txt"')
                return FileRead(self.parse_postfix())
            if (word == "file" and following is not None
                    and following.kind == "NAME" and following.value.lower() == "exists"):
                self.pos += 1  # skip "exists"
                if self.peek() is None:
                    raise NovaError("Say which file to check after 'file exists'.",
                                    hint='For example: file exists "notes.txt"')
                return FileExists(self.parse_postfix())
            if word in ("true", "false") and (following is None or following.kind != "LPAREN"):
                return Literal(word == "true")
            if word == "newline" and (following is None or following.kind != "LPAREN"):
                return Literal(NEWLINE)  # ordinary text from here on
            if following is not None and following.kind == "LPAREN":
                return self.parse_call(token.value)
            return NameRef(token.value)
        if token.kind == "LPAREN":
            return self.parse_parentheses()
        if token.kind == "LBRACKET":
            return self.parse_list()
        if token.kind == "RBRACKET":
            raise NovaError("I found a ] where I expected a number, some text, or a name.",
                            hint="Something is missing before this ].")
        if token.kind == "RPAREN":
            raise NovaError("I found a ) where I expected a number, some text, or a name.",
                            hint="Something is missing before this ).")
        raise NovaError(
            f"I found {token.value} where I expected a number, some text, or a name.",
            hint=f"Put something on both sides of {token.value}, like 10 {token.value} 5")

    def reading_a_file(self, following):
        """
        Is this 'read' the file-reading word? Almost always: 'read' is
        reserved, so it can't be a name. The exception is an operator word
        right after it, which keeps older error messages sensible.
        """
        if following is None:
            return True  # 'read' with no file named: a mistake, not a value
        return following.kind == "TEXT" or (following.kind == "NAME"
                                            and following.value.lower() not in OPERATOR_WORDS)

    def parse_length(self):
        """length of <value> -- 'length' has been read; the next token is 'of'"""
        self.pos += 1  # skip "of"
        if self.peek() is None:
            raise NovaError("Say which list to measure after 'length of'.",
                            hint="For example: length of fruits")
        return Length(self.parse_postfix())

    def parse_list(self):
        """[ item, item, ... ]"""
        self.pos += 1  # skip "["
        missing_close = NovaError("This list is missing its closing ].",
                                  hint='Lists end with ], like: ["Apple", "Mango"]')
        if self.peek() is not None and self.peek().kind == "RBRACKET":
            self.pos += 1
            return ListLiteral([])
        items = []
        while True:
            token = self.peek()
            if token is None:
                raise missing_close
            if token.kind == "COMMA":
                if items:
                    raise NovaError("There are two commas in a row in this list.",
                                    hint="Put one item between each pair of commas, like: [1, 2, 3]")
                raise NovaError("There's a comma with nothing before it in this list.",
                                hint="Start the list with an item, like: [1, 2, 3]")
            items.append(self.parse_sum())
            token = self.peek()
            if token is None:
                raise missing_close
            if token.kind == "RBRACKET":
                self.pos += 1
                return ListLiteral(items)
            if token.kind == "RPAREN":
                raise NovaError("I found a ) where the list's closing ] was expected.",
                                hint='Lists end with ], like: ["Apple", "Mango"]')
            if token.kind != "COMMA":
                raise NovaError("The items in a list need commas between them.",
                                hint="For example: [1, 2, 3]")
            self.pos += 1  # skip ","
            if self.peek() is None:
                raise missing_close
            if self.peek().kind == "RBRACKET":
                raise NovaError("There's a comma with nothing after it in this list.",
                                hint="Remove the extra comma, or add an item: [1, 2, 3]")

    def parse_call(self, name):
        """name ( arguments )  -- the name has been read; the next token is "(" """
        self.pos += 1  # skip "("
        missing_close = NovaError(f"The call to '{name}' is missing its closing ).",
                                  hint=f"Add ) at the end, like: {name}(5)")
        if self.peek() is not None and self.peek().kind == "RPAREN":
            self.pos += 1
            return Call(name, [])
        args = []
        while True:
            token = self.peek()
            if token is None:
                raise missing_close
            if token.kind == "COMMA":
                raise NovaError(f"There's a comma with nothing before it in the call to '{name}'.",
                                hint=f"Separate values with commas, like: {name}(1, 2)")
            args.append(self.parse_sum())
            token = self.peek()
            if token is None:
                raise missing_close
            if token.kind == "RPAREN":
                self.pos += 1
                return Call(name, args)
            if token.kind == "RBRACKET":
                raise NovaError(f"I found a ] where the call's closing ) was expected.",
                                hint=f"For example: {name}(1, 2)")
            if token.kind != "COMMA":
                raise NovaError(f"The values inside {name}( ) need commas between them.",
                                hint=f"For example: {name}(1, 2)")
            self.pos += 1  # skip ","
            if self.peek() is None or self.peek().kind == "RPAREN":
                raise NovaError(f"There's a comma with nothing after it in the call to '{name}'.",
                                hint=f"Remove the extra comma, or add a value: {name}(1, 2)")

    def parse_parentheses(self):
        self.pos += 1  # skip "("
        if self.peek() is None:
            raise NovaError("I found a ( that was never closed.", hint="Add a ) to match it.")
        if self.peek().kind == "RPAREN":
            raise NovaError("These parentheses are empty.",
                            hint="Put something inside them, like (2 + 3)")
        inside = self.parse_sum()
        closing = self.peek()
        if closing is None:
            raise NovaError("I found a ( that was never closed.", hint="Add a ) to match it.")
        if closing.kind == "RBRACKET":
            raise NovaError("I found a ] where a ) was expected.",
                            hint="Every ( needs a ) to close it.")
        if closing.kind != "RPAREN":
            raise NovaError(
                "Two values are sitting next to each other with nothing joining them.",
                hint='Use + to join them, like "Hi " + name')
        self.pos += 1  # skip ")"
        return inside
