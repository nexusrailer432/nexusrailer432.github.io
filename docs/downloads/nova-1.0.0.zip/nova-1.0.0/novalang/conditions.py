"""
Conditions: the part after 'if' or 'while'.

The six forms (one condition per line; no 'and' / 'or' yet):
  age is 18                equal
  age is not 18            not equal
  age is greater than 18   bigger       (also: is above)
  age is less than 18      smaller      (also: is below)
  age is 18 or more        bigger or equal
  age is 18 or less        smaller or equal

Both sides are ordinary NOVA expressions, so this works too:
  total is price * 2 or more
"""

from dataclasses import dataclass

from .commands import STATEMENT_WORDS
from .errors import NovaError
from .expressions import contains_call, evaluate_now, evaluate_steps, too_deep_error
from .parser import FileExists, Literal, parse_expression
from .tokenizer import is_word, tokenize
from .values import (MAX_DECIMALS, describe, is_boolean, is_list, is_number, is_text,
                     too_nested_error)

USAGES = {"if": "if age is 18 or more", "while": "while count is 5 or less"}
COMPARISON_WORDS = ("greater", "less", "above", "below")


@dataclass
class Condition:
    left: object      # expression tree
    operator: str     # == != > < >= <=
    right: object     # expression tree
    has_call: bool = False  # worked out once when parsed, not every time it's checked

    def __post_init__(self):
        self.has_call = contains_call(self.left) or contains_call(self.right)


def article(keyword):
    """'an if', 'a while': for messages that work for both block types."""
    return f"an {keyword}" if keyword[0] in "aeiou" else f"a {keyword}"


def parse_condition(text, keyword="if"):
    """
    Turn the text after 'if' or 'while' into a Condition, with friendly errors.
    `keyword` only changes the wording of error messages.
    """
    usage = USAGES[keyword]
    tokens = tokenize(text)
    if not tokens:
        raise NovaError(f"'{keyword}' needs something to check.", hint=f"For example: {usage}")

    is_position = next((i for i, token in enumerate(tokens) if is_word(token, "is")), None)
    if is_position is None and is_word(tokens[0], "file") and len(tokens) > 1 \
            and is_word(tokens[1], "exists"):
        return file_exists_condition(tokens, keyword)
    if is_position is None:
        comparison = next((t for t in tokens if is_word(t, *COMPARISON_WORDS)), None)
        if comparison is not None:
            hint = (f"Add the word 'is' before '{comparison.value}', like: "
                    f"{keyword} age is {comparison.value.lower()}"
                    f"{' than' if comparison.value.lower() in ('greater', 'less') else ''} 18")
        else:
            hint = f"For example: {usage}"
        raise NovaError(f"{article(keyword).capitalize()} needs the word 'is' to compare two things.",
                        hint=hint)

    left = tokens[:is_position]
    if not left:
        raise NovaError("Say what to check before 'is'.", hint=f"For example: {usage}")

    operator, right = split_comparison(tokens[is_position + 1:], keyword)
    check_one_condition(left + right, keyword)
    if not right:
        raise NovaError(f"This {keyword} doesn't say what to compare against.",
                        hint=f"For example: {usage}")

    try:
        return Condition(parse_expression(left), operator, parse_expression(right))
    except RecursionError:
        raise too_deep_error() from None


def file_exists_condition(tokens, keyword):
    """
    if file exists "save.txt"   -- the one condition that needs no 'is'.
    It means exactly: if file exists "save.txt" is true
    """
    check_one_condition(tokens, keyword)
    try:
        tree = parse_expression(tokens)
    except RecursionError:
        raise too_deep_error() from None
    if not isinstance(tree, FileExists):  # something follows the path
        raise NovaError(f"{article(keyword).capitalize()} line with 'file exists' can only check "
                        "one file.",
                        hint=f'For example: {keyword} file exists "notes.txt"')
    return Condition(tree, "==", Literal(True))


def ends_with_or_more_or_less(tokens):
    return len(tokens) >= 2 and is_word(tokens[-2], "or") and is_word(tokens[-1], "more", "less")


def split_comparison(rest, keyword="if"):
    """
    Read the comparison words after 'is'. Returns (operator, right-side tokens).
    """
    first = rest[0] if rest else None
    second = rest[1] if len(rest) > 1 else None

    if is_word(first, "not"):
        if is_word(second, *COMPARISON_WORDS):
            raise NovaError(f"NOVA doesn't understand 'is not {second.value}' yet.",
                            hint="Flip it instead: 'is not greater than 18' means 'is 18 or less'.")
        operator, written, right = "!=", "is not", rest[1:]
    elif is_word(first, "greater", "less"):
        word = first.value.lower()
        if not is_word(second, "than"):
            raise NovaError(f"After 'is {first.value}', NOVA expects the word 'than'.",
                            hint=f"For example: {keyword} age is {word} than 18")
        operator, written, right = (">" if word == "greater" else "<"), f"is {word} than", rest[2:]
    elif is_word(first, "above", "below"):
        operator = ">" if first.value.lower() == "above" else "<"
        written, right = f"is {first.value.lower()}", rest[1:]
    elif ends_with_or_more_or_less(rest):
        return (">=" if rest[-1].value.lower() == "more" else "<="), rest[:-2]
    else:
        return "==", rest

    if ends_with_or_more_or_less(right):
        raise NovaError(f"Use either '{written}' or 'or {right[-1].value.lower()}', not both.",
                        hint=f"For example: '{keyword} age is greater than 18' "
                             f"or '{keyword} age is 18 or more'")
    return operator, right


def check_one_condition(tokens, keyword="if"):
    """Catch things a condition can't contain yet, with specific advice."""
    for token in tokens:
        if is_word(token, "and", "or", "is"):
            if keyword == "if":
                hint = "Put a second if inside the first one to check two things."
            else:
                hint = f"Check one thing in the {keyword} line, and put an if inside the loop for the other."
            raise NovaError(f"{article(keyword).capitalize()} can only check one thing at a time "
                            "in NOVA right now.", hint=hint)
        if is_word(token, "then"):
            raise NovaError(f"NOVA doesn't use 'then' in {article(keyword)} line.",
                            hint=f"Just write the condition, like: {USAGES[keyword]}")
        if is_word(token, *STATEMENT_WORDS):
            raise NovaError(f"{article(keyword).capitalize()} line holds only the condition.",
                            hint=f"Put commands on the lines below the {keyword}, and end with done.")


def evaluate_condition(condition, variables):
    """Work out whether a condition is true. Use with 'yield from' (sides may call functions)."""
    if condition.has_call:
        left = yield from evaluate_steps(condition.left, variables)
        right = yield from evaluate_steps(condition.right, variables)
    else:
        left = evaluate_now(condition.left, variables)
        right = evaluate_now(condition.right, variables)
    return compare(condition.operator, left, right)


def comparable_number(number):
    """
    Numbers are compared at display precision, so a check agrees with what
    'say' shows: 0.1 + 0.2 displays as 0.3, and is 0.3. Stored values are
    never changed.
    """
    return round(number, MAX_DECIMALS) if isinstance(number, float) else number


def text_order(text):
    """Alphabetical order that ignores capital letters (ties broken exactly)."""
    return (text.casefold(), text)


def values_equal(left, right):
    """
    Equal means: same type and same value.
      numbers at display precision, text exactly (capitals count),
      lists item by item, in order, using these same rules.
    A number, a text, and a list are never equal to each other.
    """
    if is_number(left) and is_number(right):
        return comparable_number(left) == comparable_number(right)
    if is_text(left) and is_text(right):
        return left == right  # exact, including capital letters
    if is_boolean(left) or is_boolean(right):
        return is_boolean(left) and is_boolean(right) and left == right
    if is_list(left) and is_list(right):
        return (len(left.items) == len(right.items)
                and all(values_equal(a, b) for a, b in zip(left.items, right.items)))
    return False


def compare(operator, left, right):
    if operator in ("==", "!="):
        try:
            same = values_equal(left, right)
        except RecursionError:
            raise too_nested_error() from None
        return same if operator == "==" else not same

    if is_number(left) and is_number(right):  # the common case first
        a, b = comparable_number(left), comparable_number(right)
    elif is_boolean(left) or is_boolean(right):
        raise NovaError("true and false can't be compared as bigger or smaller.",
                        hint="Check them with 'is true' or 'is false'.")
    elif is_list(left) or is_list(right):
        raise NovaError("Lists can't be compared as bigger or smaller.",
                        hint="Check if two lists are the same with 'is', or compare their "
                             "lengths, like: if length of a is greater than length of b")
    elif is_text(left) and is_text(right):
        a, b = text_order(left), text_order(right)
    else:
        raise NovaError(
            f"I can't tell if {describe(left)} is bigger or smaller than {describe(right)}.",
            hint="Text can only be compared with text, and numbers with numbers. "
                 "If a value came from ask, add 'as a number' to the end of that ask line.")

    if operator == ">":
        return a > b
    if operator == "<":
        return a < b
    if operator == ">=":
        return a >= b
    return a <= b
