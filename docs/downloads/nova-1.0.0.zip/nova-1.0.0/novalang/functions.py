"""
Functions: define, calls, and scopes.

  define add(a, b)          a DefineBlock; registered before the program runs
      return a + b
  done

  say add(5, 3)             a call inside an expression (see expressions.py)
  greet("Alex")             a call on its own line (a CallLine)

Vocabulary: a definition has PARAMETERS (define add(a, b));
a call supplies ARGUMENTS (add(2, 3)).

Scope rules:
  - Each call gets its own local variables. Parameters are local.
  - A function can READ global variables, but every write (remember,
    ask, copy) goes to its own locals.
  - A function sees only its own locals and the globals, never the
    locals of whoever called it.
"""

import re
from collections import ChainMap
from dataclasses import dataclass

from .blocks import Block
from .commands import VALID_NAME, check_name, check_not_reserved
from .errors import NovaError, closest_match
from .values import stored

DEFINE_USAGE = "define greet(name)"

# Words a function may not be named. NOVA's commands and block keywords,
# plus 'is', 'and', 'or', which would make conditions ambiguous.
RESERVED_NAMES = ["say", "remember", "ask", "copy", "if", "otherwise", "done",
                  "repeat", "while", "define", "return", "is", "and", "or", "true", "false", "read", "newline"]

# Found by a quick scan of every line, so calls can come before definitions.
DEFINE_NAME = re.compile(r"^\s*define\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", re.IGNORECASE)
# A line that is a function call on its own:  greet("Alex")
CALL_LINE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*\(")


@dataclass
class Function:
    name: str          # as written in the define line
    params: list       # parameter names, as written
    body: list         # the lines inside define ... done
    line_number: int

    def signature(self):
        return f"{self.name}({', '.join(self.params)})"


@dataclass
class DefineBlock(Block):
    keyword = "define"
    description = "function"


class Scope(ChainMap):
    """
    The variables a piece of code can see, plus the program's functions.
    Reads look in each map in order; writes always go to the first map.
      top level:        Scope(globals)
      inside a call:    Scope(locals, globals)
    """

    def __init__(self, *maps, functions):
        super().__init__(*maps)
        self.functions = functions

    @property
    def globals(self):
        return self.maps[-1]


# ---------------------------------------------------------------------------
# define lines
# ---------------------------------------------------------------------------

def declared_function_names(lines):
    """Every name that some define line declares (quick scan, before the full pass)."""
    names = set()
    for line in lines:
        match = DEFINE_NAME.match(line)
        if match:
            names.add(match.group(1).lower())
    return names


def parse_define_header(header):
    """'add(a, b)' -> ("add", ["a", "b"]), with friendly errors."""
    open_at = header.find("(")
    if open_at == -1:
        words = header.split()
        example = words[0] if words and VALID_NAME.match(words[0]) else "greet"
        raise NovaError("A function definition needs parentheses after its name, "
                        "even when it has no parameters.", hint=f"For example: define {example}()")

    name_words = header[:open_at].split()
    if not name_words:
        raise NovaError("This define is missing the function's name.",
                        hint=f"For example: {DEFINE_USAGE}")
    if name_words[0].lower() == "my":
        raise NovaError("Function names don't use 'my'.",
                        hint=f"Try: define {' '.join(name_words[1:]) or 'greet'}(...)")
    name = check_name(name_words)
    if name.lower() in RESERVED_NAMES:
        raise NovaError(f"'{name}' is a NOVA word, so it can't be used as a function name.",
                        hint="Choose another name, like greet or add_numbers.")

    close_at = header.find(")", open_at)
    if close_at == -1:
        raise NovaError("The parameter list is missing its closing ).",
                        hint=f"For example: define {name}(a, b)")
    if header[close_at + 1:].strip():
        raise NovaError("Nothing can come after the ) in a define line.",
                        hint="Put the function's commands on the lines below, and end with done.")
    return name, parse_parameters(header[open_at + 1:close_at], name)


def parse_parameters(inside, function_name):
    """'a, b' -> ["a", "b"]"""
    if not inside.strip():
        return []
    params, seen = [], set()
    for piece in inside.split(","):
        words = piece.split()
        if not words:
            raise NovaError("There's an empty spot in the parameter list.",
                            hint=f"Separate parameter names with commas, like: define {function_name}(a, b)")
        if words[0].lower() == "my":
            raise NovaError("Parameter names don't use 'my'.",
                            hint=f"Just write the name, like: define {function_name}(name)")
        if len(words) > 1:
            raise NovaError(f"Parameter names must be separated by commas, but I found: {' '.join(words)}",
                            hint=f"For example: define {function_name}(first, second)")
        param = words[0]
        if not VALID_NAME.match(param):
            raise NovaError(f"'{param}' can't be used as a parameter name.",
                            hint="Parameter names follow the usual name rules: a letter first, "
                                 "then letters, numbers, or _")
        check_not_reserved(param)  # a parameter named 'true' or 'newline' could never be read
        if param.lower() in seen:
            raise NovaError(f"The parameter name '{param}' appears twice.",
                            hint=f"Give each parameter its own name, like: define {function_name}(a, b)")
        seen.add(param.lower())
        params.append(param)
    return params


# ---------------------------------------------------------------------------
# Calls
# ---------------------------------------------------------------------------

def unknown_function_error(name, known_functions, variables=()):
    key = name.lower()
    if key in RESERVED_NAMES:
        return NovaError(f"'{name}' is a NOVA word, not a function, so it can't be used with ( ).",
                         hint='Write it the normal way, like: say "Hello"')
    if key in variables:
        return NovaError(f"'{name}' is a remembered value, not a function.",
                         hint="Only functions made with define can be used with ( ).")
    suggestion = closest_match(key, list(known_functions))
    if key in ("len", "length", "size") and not suggestion:
        hint = "To count the items in a list, use: length of fruits"
    elif suggestion:
        hint = f"Did you mean '{suggestion}'?"
    else:
        hint = f"Create it first with: define {name}() ... done"
    return NovaError(f"I don't know a function called '{name}'.", hint=hint)


def check_argument_count(function, received):
    expected = len(function.params)
    if expected != received:
        noun = "argument" if expected == 1 else "arguments"
        raise NovaError(f"Function '{function.name}' expects {expected} {noun}, "
                        f"but received {received}.",
                        hint=f"Call it like: {function.signature()}")


def check_call(name, argument_count, functions, variable_names):
    """
    Check a call without running anything: the function must exist and
    receive the right number of arguments. Used by validation (with every
    name the program ever remembers) and by the runtime (with the live scope).
    """
    function = functions.get(name.lower())
    if function is None:
        raise unknown_function_error(name, functions, variable_names)
    check_argument_count(function, argument_count)
    return function


def resolve_call(request, scope):
    """Find the function a CallRequest asks for (the runtime's final check)."""
    return check_call(request.name, len(request.args), scope.functions, scope)


def call_scope(function, args, scope):
    """A fresh scope for one call: parameters as locals, globals readable."""
    local = {param.lower(): stored(value) for param, value in zip(function.params, args)}
    return Scope(local, scope.globals, functions=scope.functions)


