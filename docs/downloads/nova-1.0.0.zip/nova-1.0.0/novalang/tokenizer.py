"""Tokenizer: breaks expression text into tokens."""

from dataclasses import dataclass

from .errors import NovaError
from .values import DIGITS_ONLY, parse_number


@dataclass
class Token:
    kind: str      # NUMBER, TEXT, NAME, OP, LPAREN, RPAREN, LBRACKET, RBRACKET, COMMA
    value: object  # the number, the text, the word, or the symbol


SYMBOLS = {"+": "OP", "-": "OP", "*": "OP", "/": "OP",
           "(": "LPAREN", ")": "RPAREN", "[": "LBRACKET", "]": "RBRACKET", ",": "COMMA"}
COMPARISON_SYMBOLS = "<>=!"


def is_word(token, *words):
    """Is this token one of the given words (case-insensitive)?"""
    return token is not None and token.kind == "NAME" and token.value.lower() in words


def tokenize(text):
    """
    Break an expression into tokens.

    '"Hey " + name'  ->  [TEXT "Hey "] [OP +] [NAME name]
    """
    tokens = []
    i = 0
    while i < len(text):
        char = text[i]

        if char.isspace():
            i += 1

        elif char == '"':
            end = text.find('"', i + 1)
            if end == -1:
                raise NovaError(
                    "This text is missing its closing quote mark (\").",
                    hint='Text must start and end with a quote, like "Hello".')
            tokens.append(Token("TEXT", text[i + 1:end]))
            i = end + 1

        elif char in SYMBOLS:
            tokens.append(Token(SYMBOLS[char], char))
            i += 1

        elif char.isdigit():
            start = i
            while i < len(text) and (text[i].isdigit() or text[i] == "."):
                i += 1
            tokens.append(number_token(text[start:i]))

        elif char.isalpha() or char == "_":
            start = i
            while i < len(text) and (text[i].isalnum() or text[i] == "_"):
                i += 1
            tokens.append(Token("NAME", text[start:i]))

        elif char == "'":
            raise NovaError(
                "NOVA uses double quotes (\") for text, not single quotes (').",
                hint='Try: say "Hello"')

        elif char == "." and i + 1 < len(text) and text[i + 1].isdigit():
            raise NovaError("A decimal number needs a digit before the point.",
                            hint="Write 0.5 instead of .5")

        elif char in COMPARISON_SYMBOLS:
            raise NovaError(
                f"I don't understand the symbol '{char}' here.",
                hint="NOVA compares with words, like: if age is greater than 18")

        elif char == ".":
            raise NovaError(
                "I don't understand the symbol '.' here.",
                hint="NOVA doesn't use dots between names. To count the items in a list, "
                     "use: length of fruits")

        else:
            raise NovaError(
                f"I don't understand the symbol '{char}' here.",
                hint="NOVA understands + - * / ( ) [ ] and commas, plus quotes for text.")
    return tokens


def number_token(chunk):
    """Turn a run of digits and dots into a NUMBER (or TEXT for codes like 007)."""
    number = parse_number(chunk)
    if number is not None:
        return Token("NUMBER", number)
    if DIGITS_ONLY.match(chunk):
        return Token("TEXT", chunk)  # leading zeros: 007 stays text
    raise NovaError(f"'{chunk}' isn't a number I understand.",
                    hint=f'Numbers look like 15 or 3.14. If you meant text, put it in quotes: "{chunk}"')
