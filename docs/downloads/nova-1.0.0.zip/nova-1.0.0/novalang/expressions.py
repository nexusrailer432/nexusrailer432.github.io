"""
Expression evaluator: expression tree -> value.

Two ways to evaluate, sharing the same rules:
  evaluate()        plain and fast; for expressions with no function calls
                    (the vast majority).
  evaluate_steps()  a generator that can pause. When it reaches a function
                    call, it yields a CallRequest; the runtime runs the
                    function and sends back its value. This is what lets
                    'say add(5, 3)' work without the interpreter calling
                    itself, so NOVA recursion depth isn't tied to Python's.

Use evaluate_steps() with 'yield from'.
"""

from dataclasses import dataclass

from .errors import NovaError, UnknownNameError, closest_match
from .files import file_exists, read_file
from .lists import get_item, length_of
from .parser import (BinaryOp, Call, FileExists, FileRead, Index, Length, ListLiteral, Literal,
                     NameRef, Negate, parse_expression, render_expression)
from .tokenizer import tokenize
from .values import (DIGITS_ONLY, NOTHING, NovaList, describe, describe_text, is_boolean, is_list,
                     is_number, is_text, make_number, to_text)

VERBS = {"-": "subtract", "*": "multiply", "/": "divide"}


@dataclass
class CallRequest:
    """Yielded to the runtime: 'please run this function and send back its value'."""
    name: str
    args: list


# ---------------------------------------------------------------------------
# Shared rules
# ---------------------------------------------------------------------------

def lookup_variable(name, variables):
    """Get the value of a remembered name, or explain why it's missing."""
    key = name.lower()
    if key in variables:
        return variables[key]

    suggestion = closest_match(key, list(variables))
    if suggestion:
        hint = f"Did you mean '{suggestion}'?"
    else:
        hint = (f"Create it first with: remember my {name} as ...  "
                f"Or, if you meant the text {name}, put it in quotes: \"{name}\"")
    raise UnknownNameError(f"I don't know anything called '{name}' yet.",
                           name=name, suggestion=suggestion, hint=hint)


def apply_operator(symbol, written, left, right):
    """Combine two values with + - * /"""
    if symbol == "+" and not (is_number(left) and is_number(right)):
        if is_text(left) or is_text(right):
            return to_text(left) + to_text(right)  # text is involved: join
        if is_boolean(left) or is_boolean(right):
            hint = ("+ adds numbers, or joins text. Check true/false values with "
                    "'is true' or 'is false'.")
        else:
            hint = "To put an item in a list, use: add 5 to numbers. + adds numbers, or joins text."
        raise NovaError(f"I can't use + with {describe(left)} and {describe(right)}.", hint=hint)

    if symbol != "+":
        for value in (left, right):
            if is_list(value):
                raise NovaError(f"I can only {VERBS[symbol]} numbers, but {to_text(value)} is a list.",
                                hint="Math works on numbers. To count the items in a list, "
                                     "use: length of ...")
            if is_boolean(value):
                raise NovaError(f"I can only {VERBS[symbol]} numbers, but {to_text(value)} "
                                "is a true/false value.",
                                hint="Math works on numbers. Check true/false values with "
                                     "'is true' or 'is false'.")
            if not is_number(value):
                raise NovaError(
                    f"I can only {VERBS[symbol]} numbers, but {describe_text(value)} is text.",
                    hint=text_in_math_hint(value))
    if symbol == "/" and right == 0:
        raise NovaError("You can't divide by zero.",
                        hint=f"Check the number after {written}.")
    try:
        if symbol == "+":
            result = left + right
        elif symbol == "-":
            result = left - right
        elif symbol == "*":
            result = left * right
        else:
            result = left / right
    except OverflowError:
        raise NovaError("That number is too big for NOVA to handle.") from None
    return make_number(result)


def negate_value(value):
    if is_list(value):
        raise NovaError("I can't put a minus sign in front of a list.",
                        hint="A minus sign only works in front of a number.")
    if is_boolean(value):
        raise NovaError(f"I can't put a minus sign in front of {to_text(value)}.",
                        hint="A minus sign only works in front of a number.")
    if not is_number(value):
        raise NovaError(f"I can't put a minus sign in front of text ({describe_text(value)}).",
                        hint="A minus sign only works in front of a number.")
    return make_number(-value)


def text_in_math_hint(value):
    if is_list(value):
        return "That's a list. To count its items, use: length of ..."
    if is_boolean(value):
        return "That's a true/false value, not a number."
    if DIGITS_ONLY.match(value):
        return f"{value} starts with 0, so NOVA keeps it as text (like a code or phone number)."
    return "Only + works with text, and it joins text together."


def too_deep_error():
    return NovaError("This expression is nested too deeply for me to follow.",
                     hint="Try using fewer parentheses inside each other.")


def nothing_error(function_name):
    return NovaError(f"The function '{function_name}' didn't give back a value, "
                     "so there's nothing to use here.",
                     hint=f"Add 'return' with a value inside {function_name}, "
                          f"or call it on a line by itself.")


# ---------------------------------------------------------------------------
# Plain evaluation (no function calls)
# ---------------------------------------------------------------------------

def evaluate(node, variables):
    """Work out the value of an expression tree that contains no function calls."""
    if isinstance(node, Literal):
        return node.value
    if isinstance(node, NameRef):
        return lookup_variable(node.name, variables)
    if isinstance(node, Negate):
        return negate_value(evaluate(node.operand, variables))
    if isinstance(node, BinaryOp):
        left = evaluate(node.left, variables)
        right = evaluate(node.right, variables)
        return apply_operator(node.symbol, node.written, left, right)
    if isinstance(node, Index):
        container = evaluate(node.target, variables)
        return get_item(container, evaluate(node.index, variables), render_expression(node.target))
    if isinstance(node, ListLiteral):
        return NovaList([evaluate(item, variables) for item in node.items])
    if isinstance(node, Length):
        return length_of(evaluate(node.target, variables), render_expression(node.target))
    if isinstance(node, FileRead):
        return read_file(evaluate(node.path, variables))
    if isinstance(node, FileExists):
        return file_exists(evaluate(node.path, variables))
    raise TypeError(f"evaluate() can't handle {node!r}")  # interpreter bug, not user error


def contains_call(tree):
    """Does this expression tree contain a function call anywhere? (no recursion)"""
    waiting = [tree]
    while waiting:
        node = waiting.pop()
        if isinstance(node, Call):
            return True
        if isinstance(node, BinaryOp):  # most common first; this runs for every parsed expression
            waiting.append(node.left)
            waiting.append(node.right)
        elif not isinstance(node, (Literal, NameRef)):
            waiting.extend(children(node))
    return False


def children(node):
    """The sub-expressions of a tree node, in reading order."""
    if isinstance(node, (Negate,)):
        return [node.operand]
    if isinstance(node, BinaryOp):
        return [node.left, node.right]
    if isinstance(node, Call):
        return list(node.args)
    if isinstance(node, ListLiteral):
        return list(node.items)
    if isinstance(node, Index):
        return [node.target, node.index]
    if isinstance(node, Length):
        return [node.target]
    if isinstance(node, (FileRead, FileExists)):
        return [node.path]
    return []


# ---------------------------------------------------------------------------
# Pausable evaluation (may call functions)
# ---------------------------------------------------------------------------

def evaluate_steps(tree, variables, allow_nothing=False):
    """
    Evaluate an expression tree. Use with 'yield from'.

    allow_nothing: True only where a function's missing value may pass
    through untouched ('return f()' and a call on its own line).
    """
    try:
        if not contains_call(tree):
            return evaluate(tree, variables)
        return (yield from _evaluate_with_calls(tree, variables, allow_nothing))
    except RecursionError:
        raise too_deep_error() from None


def _evaluate_with_calls(node, variables, allow_nothing=False):
    if isinstance(node, Call):
        args = []
        for arg in node.args:  # left to right, all before the call
            args.append((yield from _evaluate_with_calls(arg, variables)))
        result = yield CallRequest(node.name, args)
        if result is NOTHING and not allow_nothing:
            raise nothing_error(node.name)
        return result
    if isinstance(node, Negate):
        return negate_value((yield from _evaluate_with_calls(node.operand, variables)))
    if isinstance(node, BinaryOp):
        left = yield from _evaluate_with_calls(node.left, variables)
        right = yield from _evaluate_with_calls(node.right, variables)
        return apply_operator(node.symbol, node.written, left, right)
    if isinstance(node, Index):
        container = yield from _evaluate_with_calls(node.target, variables)
        index = yield from _evaluate_with_calls(node.index, variables)
        return get_item(container, index, render_expression(node.target))
    if isinstance(node, ListLiteral):
        items = []
        for item in node.items:  # left to right
            items.append((yield from _evaluate_with_calls(item, variables)))
        return NovaList(items)
    if isinstance(node, Length):
        value = yield from _evaluate_with_calls(node.target, variables)
        return length_of(value, render_expression(node.target))
    if isinstance(node, FileRead):
        return read_file((yield from _evaluate_with_calls(node.path, variables)))
    if isinstance(node, FileExists):
        return file_exists((yield from _evaluate_with_calls(node.path, variables)))
    return evaluate(node, variables)  # a literal or a name


def evaluate_now(tree, variables):
    """Evaluate a tree that is known to contain no function calls."""
    try:
        return evaluate(tree, variables)
    except RecursionError:
        raise too_deep_error() from None


def calls_in(tree):
    """Every Call node in an expression tree, in reading order (no recursion)."""
    waiting = [tree]
    while waiting:
        node = waiting.pop()
        if isinstance(node, Call):
            yield node
        waiting.extend(reversed(children(node)))


def parse_text(text):
    """Tokenize and parse expression text into a tree."""
    return parse_tokens(tokenize(text))


def parse_tokens(tokens):
    """Parse a list of tokens into one tree."""
    try:
        return parse_expression(tokens)
    except RecursionError:
        raise too_deep_error() from None
