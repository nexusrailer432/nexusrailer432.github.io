"""
NOVA: a beginner-friendly programming language written in plain English.

Package layout (each module has one job):
  errors.py       NovaError and friendly-suggestion helpers
  values.py       NOVA's types (number, text, list, true/false): detection, display, copying
  tokenizer.py    expression text -> tokens
  parser.py       tokens -> expression tree (math precedence, parentheses)
  expressions.py  expression tree -> value
  lists.py        list indexing, length, and list error messages
  files.py        reading, writing, and appending text files
  conditions.py   "age is 18 or more" -> True / False
  commands.py     say, remember, ask, copy, return, set, add, remove, write, append
  blocks.py       block types: if, repeat, while
  functions.py    define, function calls, scopes
  validation.py   checks the whole program before anything runs
  runtime.py      program structure (blocks and done) and execution
  cli.py          reading .nova files and the command-line interface
"""

VERSION = "1.0.0"  # defined before the imports below, which read it

from .errors import NovaError  # noqa: E402
from .runtime import run_program  # noqa: E402

__all__ = ["VERSION", "NovaError", "run_program"]
