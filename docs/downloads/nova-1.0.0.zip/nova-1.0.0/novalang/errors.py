"""NOVA's error type and helpers for friendly suggestions."""

import difflib


class NovaError(Exception):
    """An error in a NOVA program, with a friendly message and optional hint."""

    def __init__(self, message, hint=None, line_number=None, line_text=None):
        super().__init__(message)
        self.message = message
        self.hint = hint
        self.line_number = line_number
        self.line_text = line_text
        self.inside = None  # (function name, line it was called from), if inside a function

    def at_line(self, line_number, line_text):
        """Attach a line to this error, unless it already has one. Returns self."""
        if self.line_number is None:
            self.line_number = line_number
            self.line_text = line_text
        return self

    def __str__(self):
        if self.line_number is not None:
            lines = [f"NOVA error on line {self.line_number}:",
                     f"    {self.line_text}"]
        else:
            lines = ["NOVA error:"]
        lines.append(f"  {self.message}")
        if self.hint:
            lines.append(f"  Hint: {self.hint}")
        if self.inside is not None:
            function_name, called_from = self.inside
            lines.append(f"  This happened inside the function '{function_name}', "
                         f"called on line {called_from}.")
        return "\n".join(lines)


class UnknownNameError(NovaError):
    """A name was used before anything was remembered under it."""

    def __init__(self, message, name, suggestion, hint):
        super().__init__(message, hint=hint)
        self.name = name
        self.suggestion = suggestion


def closest_match(word, options):
    """Return the option that looks most like `word`, or None."""
    matches = difflib.get_close_matches(word.lower(), options, n=1, cutoff=0.6)
    return matches[0] if matches else None
