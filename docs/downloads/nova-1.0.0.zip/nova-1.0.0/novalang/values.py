"""
NOVA's value types.

  number -> int or float     15, 3.14, -8
  text   -> str              "Alex", "007"
  list   -> NovaList         ["Apple", 15, [1, 2]]
  true/false -> bool         the answer to a yes/no check, like: file exists "a.txt"

Lists are VALUES, like numbers and text. Every time a list is stored
(remember, copy, a parameter, set, add), NOVA stores its own copy, so two
names never share one list. That is what keeps NOVA's pass-by-value and
scope rules true for lists.
"""

import math
import re

from .errors import NovaError

# A "simple number": optional minus, no leading zeros, optional decimal part.
#   15, -8, 3.14, 0.5   -> numbers
#   007, 001.50         -> NOT numbers; kept as text (codes, IDs, phone numbers)
SIMPLE_NUMBER = re.compile(r"^-?(0|[1-9][0-9]*)(\.[0-9]+)?$")

# Used only when a number is explicitly required ("as a number"):
# leading zeros are accepted there, so 007 becomes 7.
ANY_DECIMAL = re.compile(r"^-?[0-9]+(\.[0-9]+)?$")

DIGITS_ONLY = re.compile(r"^[0-9]+(\.[0-9]+)?$")

# A valid NOVA name: a letter or _ first, then letters, numbers, or _
VALID_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# Words that always mean a value, so they can never be names.
VALUE_WORDS = ("true", "false", "newline")

# The text the NOVA word 'newline' stands for: exactly one LF (U+000A),
# on every platform. NOVA has no backslash escapes, so this word is the
# only way to build a line break inside text.
NEWLINE = "\n"
MAX_DECIMALS = 10


class Nothing:
    """
    What a function gives back when it has no return value.
    Internal only: NOVA users never see it. It may be passed along by
    'return f()' or ignored by a call on its own line; any other use is an error.
    """

    def __repr__(self):
        return "NOTHING"


NOTHING = Nothing()


class NovaList:
    """
    A NOVA list: a controlled runtime value holding NOVA values.
    It deliberately has no Python behaviour of its own (no ==, no +,
    no attribute access from NOVA). All list rules live in NOVA's code.
    """
    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def __repr__(self):
        return f"NovaList({self.items!r})"


def is_list(value):
    return isinstance(value, NovaList)


def too_nested_error():
    return NovaError("This list has lists inside lists too deeply for NOVA to handle.",
                     hint="Try keeping lists a few levels deep, like [[1, 2], [3, 4]].")


def _copy(value):
    if isinstance(value, NovaList):
        return NovaList([_copy(item) for item in value.items])
    return value


def stored(value):
    """
    The value to put in a variable, parameter, or list item.
    Lists are copied all the way down (and never share parts), so changing
    one stored list can never change another.
    """
    if not isinstance(value, NovaList):
        return value
    try:
        return _copy(value)
    except RecursionError:
        raise too_nested_error() from None


def is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_text(value):
    return isinstance(value, str)


def is_boolean(value):
    return isinstance(value, bool)


def format_boolean(value):
    return "true" if value else "false"


def make_number(value):
    """Tidy a numeric result: whole floats become ints, impossible results become errors."""
    if isinstance(value, float):
        if not math.isfinite(value):
            raise NovaError("That number is too big for NOVA to handle.")
        if value.is_integer():
            return int(value)
    return value


def _to_number(text):
    return make_number(float(text)) if "." in text else int(text)


def parse_number(text):
    """Return `text` as a number if it's a simple number, otherwise None."""
    return _to_number(text) if SIMPLE_NUMBER.match(text) else None


def parse_required_number(text):
    """Like parse_number, but also accepts leading zeros (007 -> 7)."""
    return _to_number(text) if ANY_DECIMAL.match(text) else None


def format_number(number):
    """Show a number the way a person would write it: 2, 2.5, 0.3333333333"""
    if isinstance(number, int):
        try:
            return str(number)
        except ValueError:  # Python refuses to print extremely long integers
            raise NovaError("That number is too long to show.") from None
    text = f"{number:.{MAX_DECIMALS}f}".rstrip("0").rstrip(".")
    return "0" if text in ("", "-0") else text


def format_list(value):
    """Show a list the way it would be written: ["Apple", 15, [1, 2]]"""
    parts = []
    for item in value.items:
        if isinstance(item, NovaList):
            parts.append(format_list(item))
        elif isinstance(item, bool):
            parts.append(format_boolean(item))
        elif is_number(item):
            parts.append(format_number(item))
        else:
            parts.append(f'"{item}"')
    return "[" + ", ".join(parts) + "]"


def to_text(value):
    """Turn any NOVA value into text for display or joining."""
    if is_number(value):
        return format_number(value)
    if isinstance(value, bool):
        return format_boolean(value)
    if isinstance(value, NovaList):
        try:
            return format_list(value)
        except RecursionError:
            raise too_nested_error() from None
    return value


def describe_text(text):
    """
    Write text the way a NOVA program would, so an error message stays on
    one line: a line break is shown as the word newline.
    """
    if text == NEWLINE:
        return "newline"
    if NEWLINE not in text:
        return f'"{text}"'
    parts = [f'"{part}"' for part in text.split(NEWLINE)]
    return " + newline + ".join(parts)


def describe(value):
    """Describe a value for an error message: the number 18, the text "Alex", the list [1, 2]."""
    if is_number(value):
        return f"the number {format_number(value)}"
    if isinstance(value, bool):
        return f"the value {format_boolean(value)}"
    if isinstance(value, NovaList):
        shown = to_text(value)
        if len(shown) <= 40 and NEWLINE not in shown:
            return f"the list {shown}"
        count = len(value.items)
        return f"a list of {count} item{'' if count == 1 else 's'}"
    return f"the text {describe_text(value)}"
