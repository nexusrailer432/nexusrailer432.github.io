"""
Program structure and execution.

    PARSE -> REGISTER DEFINITIONS -> VALIDATE -> EXECUTE

  1. parse_program() reads every line and builds the block structure:
     which lines belong inside which if / repeat / while / define /
     otherwise, and where each done is. It registers every function, so a
     function can be called before its define line. Block mistakes,
     unknown commands, bad define lines, call lines to functions that
     don't exist, and 'return' outside a function are reported here.
  2. validate_program() (validation.py) parses every command and block
     header once and checks every function call, without running anything.
  3. execute() runs the structure, reusing the parsed commands.

Nothing here uses recursion: nesting depth and function-call depth are
tracked on explicit stacks, not Python's.
"""

from dataclasses import dataclass

from . import VERSION
from .blocks import BLOCK_TYPES, EMPTY_HEADER_ERRORS, CallLine, CommandLine, IfBlock
from .commands import COMMANDS, ReturnSignal
from .errors import NovaError, closest_match
from .expressions import CallRequest
from .functions import (CALL_LINE, RESERVED_NAMES, DefineBlock, Function, Scope,
                        call_scope, declared_function_names, parse_define_header,
                        resolve_call, unknown_function_error)
from .validation import validate_program
from .tokenizer import tokenize
from .values import NOTHING

BLOCK_KEYWORDS = list(BLOCK_TYPES) + ["define", "otherwise", "done"]

# How many function calls may be running inside each other at once.
# Without a limit, a function that calls itself forever would slowly use up
# all memory. 10,000 is ten times Python's own default and far beyond what
# ordinary recursion needs; run_program() can change it.
DEFAULT_CALL_LIMIT = 10_000

# Words people bring from other languages, with advice in NOVA terms.
NO_ELSE_IF = "NOVA doesn't have 'else if'. Put a new if inside 'otherwise'."
ENDS_WITH_DONE = ("NOVA ends every if, repeat, and while block with 'done'. "
                  "Functions made with define end with 'done' too.")
USE_NOVA_LOOPS = "NOVA doesn't have 'for' loops. Use 'repeat 5 times' or 'while count is 5 or less'."
USE_DEFINE = "NOVA makes functions with define, like: define greet(name)"
FOREIGN_WORDS = {
    "else": "NOVA uses 'otherwise' instead of 'else'.",
    "elif": NO_ELSE_IF,
    "elseif": NO_ELSE_IF,
    "end": ENDS_WITH_DONE,
    "endif": ENDS_WITH_DONE,
    "endwhile": ENDS_WITH_DONE,
    "fi": ENDS_WITH_DONE,
    "for": USE_NOVA_LOOPS,
    "foreach": USE_NOVA_LOOPS,
    "each": USE_NOVA_LOOPS,
    "loop": "To run commands again and again, use 'repeat 5 times' or a while loop.",
    "do": "NOVA doesn't use 'do'. Start a loop with 'repeat' or 'while'.",
    "until": "NOVA doesn't have 'until'. Use while with the opposite condition.",
    "break": "NOVA doesn't have 'break' yet. A while loop stops when its condition becomes false.",
    "continue": "NOVA doesn't have 'continue' yet. Use an if inside the loop to skip commands.",
    "def": USE_DEFINE,
    "function": USE_DEFINE,
    "func": USE_DEFINE,
    "call": "To run a function, just write its name with parentheses, like: greet(\"Alex\")",
    "push": 'To put an item at the end of a list, use: add "Grape" to fruits',
    "insert": 'To put an item at the end of a list, use: add "Grape" to fruits',
    "pop": "To take an item out of a list, use: remove fruits[1]",
    "delete": "To take an item out of a list, use: remove fruits[1]",
    "del": "To take an item out of a list, use: remove fruits[1]",
    "open": 'NOVA reads and writes files directly, like: read "notes.txt" or write "Hi" to "notes.txt"',
    "close": "NOVA closes files by itself. There's no need to close them.",
    "save": 'To save text to a file, use: write "Hi" to "notes.txt"',
}


def is_whole_call(line):
    """
    Is this line exactly  name(...)  and nothing else?  Used so that a
    function the program defines with a command's name (like an
    favourite  define add(a, b) ) can still be called on its own line:
        add (1, 2)          -> a call to the function add
        add (1 + 2) to xs   -> the add command
    """
    try:
        tokens = tokenize(line)
    except NovaError:
        return False
    if len(tokens) < 3 or tokens[0].kind != "NAME" or tokens[1].kind != "LPAREN":
        return False
    depth = 0
    for position, token in enumerate(tokens[1:], start=1):
        if token.kind in ("LPAREN", "LBRACKET"):
            depth += 1
        elif token.kind in ("RPAREN", "RBRACKET"):
            depth -= 1
            if depth == 0:
                return position == len(tokens) - 1
    return False


def unknown_command_error(word, line, declared=()):
    """Build a helpful error for a line that doesn't start with a known command."""
    known = list(COMMANDS) + BLOCK_KEYWORDS
    if line.startswith('"'):
        hint = f"To show text, start the line with say, like: say {line}"
    elif word.lower() in declared:
        hint = f"To run the function '{word}', add parentheses: {word}()"
    elif word.lower() in FOREIGN_WORDS:
        hint = FOREIGN_WORDS[word.lower()]
    else:
        suggestion = closest_match(word, known)
        if suggestion:
            hint = f"Did you mean '{suggestion}'?"
        else:
            hint = f"NOVA v{VERSION} knows these words: {', '.join(known)}"
    return NovaError(f"I don't know the command '{word}'.", hint=hint)


# ===========================================================================
# Pass 1: structure
# ===========================================================================

@dataclass
class Program:
    body: list        # the top-level lines and blocks, in order
    functions: dict   # Function objects by lowercase name
    lines: list       # every command line, call line, and block, in source order


def parse_program(source):
    """Build the block structure of a program. Returns a Program."""
    lines = source.splitlines()
    declared = declared_function_names(lines)
    functions = {}
    every_line = []      # for validation, in source order
    top_level = []
    body = top_level     # the list new lines are added to
    open_blocks = []     # stack of (block, the body it lives in)

    for line_number, raw in enumerate(lines, start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue  # blank lines and comments do nothing
        word, _, rest = line.partition(" ")
        keyword, rest = word.lower(), rest.strip()

        def fail(message, hint=None):
            return NovaError(message, hint=hint).at_line(line_number, line)

        if keyword == "define":
            if open_blocks:
                raise fail("A function can only be defined at the top level of the program.",
                           "Move this define so it isn't inside an if, a loop, or another function.")
            if not rest:
                raise fail("'define' needs a function name and parentheses.",
                           "For example: define greet(name)")
            try:
                name, params = parse_define_header(rest)
            except NovaError as error:
                raise error.at_line(line_number, line)
            if name.lower() in functions:
                raise fail(f"A function called '{name}' is already defined "
                           f"(on line {functions[name.lower()].line_number}).",
                           "Give this function a different name, or remove one of them.")
            block = DefineBlock(line_number, line, rest)
            functions[name.lower()] = Function(name, params, block.body, line_number)
            open_blocks.append((block, body))  # not added to body: defining runs nothing
            body = block.body

        elif keyword in BLOCK_TYPES:
            if not rest:
                message, hint = EMPTY_HEADER_ERRORS[keyword]
                raise fail(message, hint)
            block = BLOCK_TYPES[keyword](line_number, line, rest)
            body.append(block)
            every_line.append(block)
            open_blocks.append((block, body))
            body = block.body

        elif keyword == "otherwise":
            if rest:
                raise fail("'otherwise' must be on a line by itself.",
                           "Put the commands on the lines below it.")
            if not open_blocks:
                raise fail("I found 'otherwise' without an 'if' before it.",
                           "'otherwise' belongs inside an if block, before its done.")
            block = open_blocks[-1][0]
            if not isinstance(block, IfBlock):
                article = "An" if block.description[0] in "aeiou" else "A"
                raise fail(
                    f"'otherwise' only works with if, but the {block.keyword} on line "
                    f"{block.line_number} is still open.",
                    f"{article} {block.description} can't have an otherwise. If this otherwise "
                    f"belongs to an if, add 'done' to finish the {block.keyword} first.")
            if block.otherwise_line is not None:
                raise fail(f"This if already has an 'otherwise' (on line {block.otherwise_line}).",
                           "Each if can have only one otherwise.")
            block.otherwise_line = line_number
            body = block.otherwise_body

        elif keyword == "done":
            if rest:
                raise fail("'done' must be on a line by itself.", "Put any commands on the next line.")
            if not open_blocks:
                raise fail("I found 'done', but nothing is open for it to finish.",
                           "done closes an if, repeat, while, or define. "
                           "Remove this done, or check for an extra one.")
            _, body = open_blocks.pop()

        elif keyword in COMMANDS and not (keyword in declared and is_whole_call(line)):
            if keyword == "return" and not (open_blocks and isinstance(open_blocks[0][0], DefineBlock)):
                raise fail("'return' only works inside a function.",
                           "Use return between 'define name()' and its 'done' to give back a value.")
            node = CommandLine(line_number, line)
            body.append(node)
            every_line.append(node)

        elif (call := CALL_LINE.match(line)):
            name = call.group(1)
            if name.lower() in RESERVED_NAMES or name.lower() not in declared:
                raise unknown_function_error(name, declared).at_line(line_number, line)
            node = CallLine(line_number, line)
            body.append(node)
            every_line.append(node)

        else:
            raise unknown_command_error(word, line, declared).at_line(line_number, line)

    if open_blocks:
        block = open_blocks[-1][0]
        raise NovaError(f"This {block.keyword} never gets a 'done' to close it.",
                        hint=f"Add 'done' on its own line after the commands inside the {block.keyword}."
                        ).at_line(block.line_number, block.text)
    return Program(top_level, functions, every_line)


# ===========================================================================
# Pass 2: execution
# ===========================================================================

@dataclass(slots=True)
class Frame:
    """One running piece of the program on the runtime stack."""
    steps: object          # the generator being driven
    scope: Scope
    node: object = None    # the line being run (for error messages)
    call: object = None    # for a function's base frame: (Function, the line that called it)


def lines_of(body):
    for node in body:
        yield node


def start(node, scope, loop_limit):
    """Begin running one line. Returns a generator to drive, or None if already finished."""
    if isinstance(node, (CommandLine, CallLine)):
        if node.command is None:  # only if execute() is used without validation
            node.validate(set(scope.functions))
        return node.command.start(scope)
    return node.run(scope, loop_limit)


def locate(error, node, stack):
    """Attach the line, and the function it happened inside, to an error."""
    if node is not None:
        error.at_line(node.line_number, node.text)
    if error.inside is None:
        for frame in reversed(stack):
            if frame.call is not None:
                function, called_from = frame.call
                error.inside = (function.name, called_from.line_number)
                break
    return error


def execute(body, scope, loop_limit=None, call_limit=DEFAULT_CALL_LIMIT):
    """
    Run a block structure.

    The stack holds one generator per running piece: the program's lines,
    each open block, each command that is working, and each function call.
    A generator can yield:
      a line         -> start it and push it on the stack
      CallRequest    -> push the function's body with a fresh scope
      ReturnSignal   -> pop everything back to the function's base frame
                        and send the value to whoever made the call
    When a generator finishes, its parent is resumed. A function that ends
    without return gives back NOTHING.
    """
    stack = [Frame(lines_of(body), scope)]
    reply = None
    depth = 0  # function calls currently running

    while stack:
        frame = stack[-1]
        try:
            item = frame.steps.send(reply)
        except StopIteration:
            stack.pop()
            if frame.call is not None:  # a function reached its done
                depth -= 1
                reply = NOTHING
            else:
                reply = None
            continue
        except NovaError as error:
            raise locate(error, frame.node, stack)
        reply = None

        if isinstance(item, CallRequest):
            try:
                function = resolve_call(item, frame.scope)
                if depth >= call_limit:
                    raise NovaError(
                        f"Functions are calling each other too deeply "
                        f"(more than {call_limit:,} calls inside calls).",
                        hint="A function that calls itself needs a way to stop, "
                             "like: if n is 0, then return.")
            except NovaError as error:
                raise locate(error, frame.node, stack)
            depth += 1
            stack.append(Frame(lines_of(function.body), call_scope(function, item.args, frame.scope),
                               call=(function, frame.node)))

        elif isinstance(item, ReturnSignal):
            while stack[-1].call is None:  # leave every block inside the function
                stack.pop().steps.close()
            stack.pop().steps.close()
            depth -= 1
            reply = item.value

        else:  # a line to run
            try:
                steps = start(item, frame.scope, loop_limit)
            except NovaError as error:
                raise locate(error, item, stack)
            if steps is not None:
                stack.append(Frame(steps, frame.scope, node=item))


def run_program(source, variables=None, loop_limit=None, call_limit=DEFAULT_CALL_LIMIT):
    """
    Run a whole NOVA program. Stops at the first error. Returns the global variables.

    loop_limit: the most rounds any single loop may run, or None for no
    limit (the default, and what the command line uses). Tests set a limit
    so a mistaken infinite loop fails with a NovaError instead of hanging.

    call_limit: how many function calls may be running inside each other.
    """
    if variables is None:
        variables = {}
    program = parse_program(source)
    validate_program(program, variables)
    execute(program.body, Scope(variables, functions=program.functions), loop_limit, call_limit)
    return variables
