"""
NOVA commands: say, remember, ask, copy, return, set, add, remove, write, append,
and call lines.

Each command is handled in two halves:
  parse_<command>(args, ...)   reads the line ONCE, during validation, and
                               reports every syntax mistake. Nothing runs.
  <Command>.start(variables)   runs the parsed command, as many times as
                               needed. Returns None when finished, or a
                               generator for the runtime to drive when the
                               command must pause (a function call, or return).

A command whose expression contains no function call runs directly, with
no generator at all; that is most commands in most programs.
"""

import re
from dataclasses import dataclass

from .errors import NovaError, UnknownNameError
from .expressions import (contains_call, evaluate_now, evaluate_steps, lookup_variable,
                          parse_text, parse_tokens)
from .files import put_file
from .lists import ADD, CHANGE, REMOVE, check_index, need_list
from .parser import WORD_OPERATORS, Call, Index, NameRef, render_expression
from .tokenizer import is_word, tokenize
from .values import (NEWLINE, NOTHING, VALID_NAME, VALUE_WORDS, NovaList, parse_number,
                     parse_required_number, stored, to_text)

# Command words that can never appear inside an if/while condition or a
# repeat count (catches  if x is 1 say "hi" ). The list commands set, add,
# and remove are left out on purpose: they are also ordinary
# names, and functions or variables called add must keep working there,
# as in  if add(1, 1) is 2.
STATEMENT_WORDS = ("say", "remember", "ask", "copy", "return")

# A valid name starts with a letter or underscore, followed by letters,
# numbers, or underscores. Example: name, first_name, player2
# 'read' always starts a file read, so it can't be a name either.
# (write and append are only special as the first word of a line, so they
#  remain usable as names.)
RESERVED_VALUE_WORDS = VALUE_WORDS + ("read",)


def check_name(words):
    """
    Make sure a name is a single valid word and return it.
    Shared by every command that stores something under a name.
    """
    if len(words) > 1:
        joined = "_".join(words)
        raise NovaError(f"A name must be one word, but I found: {' '.join(words)}",
                        hint=f"Join the words with underscores, like: {joined}")
    name = words[0]
    if not VALID_NAME.match(name):
        raise NovaError(f"'{name}' can't be used as a name.",
                        hint="Names start with a letter and use only letters, numbers, and _")
    check_not_reserved(name)
    return name


def check_not_reserved(name):
    """
    Reject the words that always mean a value in an expression.
    A parameter or variable with one of these names could never be read,
    because the word itself would win.
    """
    if name.lower() not in RESERVED_VALUE_WORDS:
        return
    if name.lower() == "newline":
        raise NovaError(f"'{name}' is the NOVA word for a line break, so it can't be used as a name.",
                        hint="Choose another name, like: line_break or spacing")
    if name.lower() == "read":
        raise NovaError(f"'{name}' is the NOVA word for reading a file, so it can't be used as a name.",
                        hint='Choose another name, like: contents. To read a file: read "notes.txt"')
    raise NovaError(f"'{name}' is a NOVA word for a true/false value, so it can't be used as a name.",
                    hint="Choose another name, like: is_saved or found")


# ---------------------------------------------------------------------------
# say
# ---------------------------------------------------------------------------

class SayCommand:
    """say "Hello " + name   ->  prints the result"""

    def __init__(self, tree):
        self.tree = tree
        self.has_call = contains_call(tree)

    def start(self, variables):
        if self.has_call:
            return self.steps(variables)
        print(to_text(evaluate_now(self.tree, variables)))

    def steps(self, variables):
        print(to_text((yield from evaluate_steps(self.tree, variables))))

    def expressions(self):
        return [self.tree]


def parse_say(args, function_names=()):
    if not args.strip():
        raise NovaError("'say' needs something to say.",
                        hint='Try: say "Hello world!"')
    return SayCommand(parse_text(args))


# ---------------------------------------------------------------------------
# remember
# ---------------------------------------------------------------------------

CALL_PATTERN = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)\s*\(")
LENGTH_OF = re.compile(r"\blength\s+of\b", re.IGNORECASE)
FILE_EXPRESSION = re.compile(r"^read\b|\bfile\s+exists\b", re.IGNORECASE)


def looks_like_math(value_text, functions=()):
    """
    Does an unquoted remember value clearly contain an operator, a call, or list syntax?

    Yes: an operator symbol standing on its own (price + 1), an operator
    word with something on both sides (price times 2, 20 divided by 4),
    a call to a function this program defines (square(8)), square
    brackets (["Apple", "Mango"], fruits[0]), or 'length of'.
    No:  Max, Alex Smith, 555-1234, Mary-Jane, Plus Size, Call me (maybe)
    """
    if "[" in value_text or LENGTH_OF.search(value_text) or FILE_EXPRESSION.search(value_text):
        return True
    for match in CALL_PATTERN.finditer(value_text):
        if match.group(1).lower() in functions:
            return True
    words = value_text.split()
    for position, word in enumerate(words):
        if word in ("+", "-", "*", "/"):
            return True
        lower = word.lower()
        has_left = position > 0
        if has_left and position < len(words) - 1 and lower in WORD_OPERATORS:
            return True
        if (has_left and lower == "divided" and position + 2 < len(words)
                and words[position + 1].lower() == "by"):
            return True
    return False


class RememberCommand:
    """
    remember my name as Alex            ->  name = "Alex"   (text)
    remember my age as 15               ->  age = 15        (number)
    remember my total as price * 2      ->  calculated
    remember my title as "Dr. " + name  ->  calculated (starts with a quote)
    """

    def __init__(self, name, value_text, tree=None, constant=None, unquoted_math=False):
        self.name = name
        self.key = name.lower()
        self.value_text = value_text
        self.tree = tree              # None means the value is a fixed constant
        self.constant = constant
        self.unquoted_math = unquoted_math
        self.has_call = tree is not None and contains_call(tree)

    def start(self, variables):
        if self.tree is None:
            variables[self.key] = self.constant
        elif self.has_call:
            return self.steps(variables)
        else:
            try:
                value = evaluate_now(self.tree, variables)
            except UnknownNameError as error:
                raise self.explain(error)
            # lists are copied when stored; checked inline because this line runs very often
            variables[self.key] = stored(value) if value.__class__ is NovaList else value

    def steps(self, variables):
        try:
            variables[self.key] = stored((yield from evaluate_steps(self.tree, variables)))
        except UnknownNameError as error:
            raise self.explain(error)

    def explain(self, error):
        """For unquoted math, point out that quotes make the value plain text."""
        if self.unquoted_math:
            quoted = f'remember my {self.name} as "{self.value_text}"'
            if error.suggestion:
                error.hint = (f"Did you mean '{error.suggestion}'? "
                              f"If this is plain text, put it in quotes: {quoted}")
            else:
                error.hint = (f"Create it first with: remember my {error.name} as ...  "
                              f"If this is plain text, put it in quotes: {quoted}")
        return error

    def expressions(self):
        return [] if self.tree is None else [self.tree]

    def assigned_names(self):
        return {self.key}


def remember_command(name, value_text, function_names):
    """
    Decide once what a remember value means:
      "Dr. " + name     -> expression (starts with a quote)
      price * 2         -> expression (clearly contains an operator)
      square(8)         -> expression (calls a defined function)
      [1, 2], items[0]  -> expression (list syntax), and anything with 'length of'
      read "notes.txt"  -> expression (starts with read), and anything with 'file exists'
      true, false       -> a true/false value
      newline           -> text holding one line break
      15, -5, 3.14      -> number
      Max, Alex Smith   -> text, exactly as written (even if a name 'max' exists)
    """
    if value_text.startswith('"'):
        return RememberCommand(name, value_text, tree=parse_text(value_text))
    if value_text.lower() in VALUE_WORDS:
        word = value_text.lower()
        return RememberCommand(name, value_text,
                               constant=NEWLINE if word == "newline" else word == "true")
    if looks_like_math(value_text, function_names):
        try:
            tree = parse_text(value_text)
        except NovaError as error:
            if FILE_EXPRESSION.search(value_text):  # e.g. "read a good book": probably plain text
                error.hint = f'If this is plain text, put it in quotes: remember my {name} as "{value_text}"'
            raise
        return RememberCommand(name, value_text, tree=tree, unquoted_math=True)
    number = parse_number(value_text)
    return RememberCommand(name, value_text, constant=value_text if number is None else number)


def parse_remember(args, function_names=()):
    if not args.strip():
        raise NovaError("'remember' needs a name and a value.",
                        hint="Try: remember my name as Alex")

    parts = re.split(r"\s+as\b", " " + args, maxsplit=1, flags=re.IGNORECASE)
    if len(parts) < 2:
        raise NovaError("I couldn't find the word 'as' in this line.",
                        hint="Use the pattern: remember my name as Alex")

    name_words = parts[0].split()
    value_text = parts[1].strip()

    if name_words and name_words[0].lower() == "my":
        name_words = name_words[1:]

    if not name_words:
        raise NovaError("You didn't say what to call this memory.",
                        hint="Put a name before 'as', like: remember my name as Alex")

    name = check_name(name_words)
    if not value_text:
        raise NovaError(f"You didn't say what '{name}' should be.",
                        hint=f"Add a value after 'as', like: remember my {name} as Alex")

    return remember_command(name, value_text, function_names)


# ---------------------------------------------------------------------------
# copy
# ---------------------------------------------------------------------------

COPY_USAGE = "copy price as backup"


class CopyCommand:
    """copy price as backup   ->  backup gets price's value, same type"""

    def __init__(self, source, target):
        self.source = source
        self.key = target.lower()

    def start(self, variables):
        variables[self.key] = stored(lookup_variable(self.source, variables))

    def expressions(self):
        return []

    def assigned_names(self):
        return {self.key}


def parse_copy(args, function_names=()):
    words = args.split()
    if not words:
        raise NovaError("'copy' needs something to copy and a new name.",
                        hint=f"Try: {COPY_USAGE}")

    as_positions = [i for i, word in enumerate(words) if word.lower() == "as"]
    if not as_positions:
        raise NovaError("I couldn't find the word 'as' in this line.",
                        hint=f"Use the pattern: {COPY_USAGE}")
    split_at = as_positions[0]
    source_words, target_words = words[:split_at], words[split_at + 1:]

    if not source_words:
        raise NovaError("You didn't say what to copy.",
                        hint=f"Put a name before 'as', like: {COPY_USAGE}")
    if not target_words:
        raise NovaError("You didn't say what to call the copy.",
                        hint=f"Put a new name after 'as', like: {COPY_USAGE}")
    for part in (source_words, target_words):
        if part[0].lower() == "my":
            rest = " ".join(part[1:]) or "name"
            raise NovaError("In a copy line, write names without 'my'.",
                            hint=f"Try just: {rest}")

    return CopyCommand(check_name(source_words), check_name(target_words))


# ---------------------------------------------------------------------------
# ask
# ---------------------------------------------------------------------------

ASK_USAGE = 'ask "What\'s your name?" and remember answer as name'
ASK_NUMBER_USAGE = 'ask "How old are you?" and remember answer as age as a number'
NOT_A_NUMBER_MESSAGE = "That's not a number. Please type a number, like 18 or 3.5."
REQUIRED_NUMBER_WORDS = ["as", "a", "number"]


def parse_ask(args):
    """
    Split an ask line into (question, name, number_required).

    Expected shape:  "<question>" and remember answer as <name> [as a number]
    Each missing or wrong piece gets its own friendly error.
    """
    text = args.strip()
    if not text:
        raise NovaError("'ask' needs a question in quotes.",
                        hint=f"Try: {ASK_USAGE}")
    if not text.startswith('"'):
        raise NovaError("The question after 'ask' must be in double quotes.",
                        hint=f"Try: {ASK_USAGE}")

    end = text.find('"', 1)
    if end == -1:
        raise NovaError("This question is missing its closing quote mark (\").",
                        hint=f"Try: {ASK_USAGE}")
    question = text[1:end]
    words = text[end + 1:].split()

    if not words:
        raise NovaError("You asked a question, but didn't say where to keep the answer.",
                        hint=f"Add 'and remember answer as name' after the question, like: {ASK_USAGE}")

    # Walk through the fixed words one by one: and, remember, answer, as
    expected = ["and", "remember", "answer", "as"]
    for position, keyword in enumerate(expected):
        if position >= len(words):
            if keyword == "as":
                raise NovaError("You didn't say what to call the answer.",
                                hint=f"Finish the line with a name, like: {ASK_USAGE}")
            raise NovaError(f"This line stops too early. I expected the word '{keyword}' next.",
                            hint=f"The full pattern is: {ASK_USAGE}")
        if words[position].lower() != keyword:
            raise ask_keyword_error(keyword, words[position])

    name_words = words[len(expected):]
    number_required = False
    if [w.lower() for w in name_words[-3:]] == REQUIRED_NUMBER_WORDS:
        number_required = True
        name_words = name_words[:-3]
    elif [w.lower() for w in name_words] == ["a", "number"]:
        name_words = []  # "remember answer as a number": the name is missing

    if not name_words:
        raise NovaError("You didn't say what to call the answer.",
                        hint=f"Finish the line with a name, like: {ASK_NUMBER_USAGE if number_required or len(words) > 4 else ASK_USAGE}")
    if name_words[0].lower() == "my":
        raise NovaError("In an ask line, write the name without 'my'.",
                        hint=f"Try: ... and remember answer as {' '.join(name_words[1:]) or 'name'}")
    if len(name_words) > 1 and name_words[1].lower() == "as":
        raise NovaError("After the name, NOVA only understands 'as a number'.",
                        hint=f"For example: {ASK_NUMBER_USAGE}")
    return question, check_name(name_words), number_required


def ask_keyword_error(expected, found):
    """Explain which fixed word of the ask pattern is missing or wrong."""
    messages = {
        "and": "After the question, NOVA expects the word 'and'.",
        "remember": "After 'and', NOVA expects the word 'remember'.",
        "answer": "After 'remember', NOVA expects the word 'answer'.",
        "as": "After 'answer', NOVA expects the word 'as'.",
    }
    return NovaError(f"{messages[expected]} I found '{found}' instead.",
                     hint=f"The full pattern is: {ASK_USAGE}")


def read_answer(prompt):
    try:
        return input(prompt).strip()
    except EOFError:
        raise NovaError("I was waiting for an answer, but there was nothing to read.",
                        hint="Run the program in a terminal so you can type your answer.") from None


class AskCommand:
    """
    ask "What's your name?" and remember answer as name
        Simple numbers (15, 3.14, -8) become numbers; everything else,
        including codes with leading zeros (007), stays text.

    ask "How old are you?" and remember answer as age as a number
        The answer must be a number. If it isn't, NOVA explains and asks again.

    'answer' is a keyword here, not a variable.
    """

    def __init__(self, question, name, number_required):
        self.prompt = question if question.endswith(" ") or not question else question + " "
        self.key = name.lower()
        self.number_required = number_required

    def start(self, variables):
        while True:
            reply = read_answer(self.prompt)
            if not self.number_required:
                number = parse_number(reply)
                variables[self.key] = reply if number is None else number
                return
            number = parse_required_number(reply)
            if number is not None:
                variables[self.key] = number
                return
            print(NOT_A_NUMBER_MESSAGE)

    def expressions(self):
        return []

    def assigned_names(self):
        return {self.key}


def parse_ask_command(args, function_names=()):
    return AskCommand(*parse_ask(args))


# ---------------------------------------------------------------------------
# return
# ---------------------------------------------------------------------------

@dataclass
class ReturnSignal:
    """Yielded to the runtime: 'stop this function and give back this value'."""
    value: object


class ReturnCommand:
    """
    return <expression>   ->  stop the function, give back the value
    return                ->  stop the function, give back no value
    (The structure pass makes sure return only appears inside a function.)
    """

    def __init__(self, tree):
        self.tree = tree  # None for a bare return

    def start(self, variables):
        return self.steps(variables)  # always pauses: the runtime must unwind the call

    def steps(self, variables):
        if self.tree is None:
            value = NOTHING
        else:
            value = yield from evaluate_steps(self.tree, variables, allow_nothing=True)
        yield ReturnSignal(value)

    def expressions(self):
        return [] if self.tree is None else [self.tree]


def parse_return(args, function_names=()):
    return ReturnCommand(parse_text(args) if args.strip() else None)


# ---------------------------------------------------------------------------
# call lines:  greet("Alex")
# ---------------------------------------------------------------------------

class CallLineCommand:
    """A line that is only a function call. Any value it gives back is ignored."""

    def __init__(self, tree):
        self.tree = tree

    def start(self, variables):
        return self.steps(variables)

    def steps(self, variables):
        yield from evaluate_steps(self.tree, variables, allow_nothing=True)

    def expressions(self):
        return [self.tree]


def parse_call_line(text):
    tree = parse_text(text)
    if not isinstance(tree, Call):
        raise NovaError("A line that starts with a function call can only hold that one call.",
                        hint=f"To show the result, use say: say {text}")
    return CallLineCommand(tree)


# ---------------------------------------------------------------------------
# set / add / remove  (lists)
# ---------------------------------------------------------------------------
#
# These change the list stored in a variable, in the CURRENT scope, exactly
# as if the whole changed list had been remembered there:
#   - at the top level, the program's own variable changes;
#   - inside a function, a parameter or local list changes in place, but a
#     GLOBAL list is first copied into a local variable of the same name
#     (writes inside functions are always local), so the global never changes.

SET_USAGE = 'set fruits[1] as "Orange"'
ADD_USAGE = 'add "Grape" to fruits'
REMOVE_USAGE = "remove fruits[1]"


def split_at_word(tokens, word, last=False):
    """Split tokens at a standalone word that isn't inside ( ) or [ ]. Returns (before, after) or None."""
    depth, found = 0, None
    for position, token in enumerate(tokens):
        if token.kind in ("LPAREN", "LBRACKET"):
            depth += 1
        elif token.kind in ("RPAREN", "RBRACKET"):
            depth -= 1
        elif depth == 0 and is_word(token, word):
            found = position
            if not last:
                break
    if found is None:
        return None
    return tokens[:found], tokens[found + 1:]


def unclosed_bracket_error(tokens):
    """If a ( or [ in these tokens is never closed, return an error naming it."""
    opened = []
    for token in tokens:
        if token.kind in ("LPAREN", "LBRACKET"):
            opened.append(token.value)
        elif token.kind in ("RPAREN", "RBRACKET") and opened:
            opened.pop()
    if opened:
        closer = ")" if opened[-1] == "(" else "]"
        return NovaError(f"I found a {opened[-1]} that was never closed.",
                         hint=f"Add a {closer} to match it.")
    return None


def missing_word_error(tokens, word, usage):
    """The word wasn't found outside brackets: blame an unclosed bracket if there is one."""
    return unclosed_bracket_error(tokens) or NovaError(
        f"I couldn't find the word '{word}' in this line.", hint=f"Use the pattern: {usage}")


def list_target(tokens, command, usage, need_index):
    """
    Read the list a command changes: a stored name, then any [index] parts.
    Returns (root name, index trees, descriptions of each list on the way down).
    """
    if tokens and is_word(tokens[0], "my"):
        raise NovaError(f"In a {command} line, write the list's name without 'my'.",
                        hint=f"For example: {usage}")
    tree = parse_tokens(tokens)
    indexes = []
    node = tree
    while isinstance(node, Index):
        indexes.append(node.index)
        node = node.target
    if not isinstance(node, NameRef):
        raise NovaError(f"'{command}' needs a list stored under a name.",
                        hint=f"For example: {usage}")
    if need_index and not indexes:
        if command == "set":
            raise NovaError("set changes one item in a list, so it needs an index, like fruits[1].",
                            hint=f"For example: {usage}. To store a whole value, use: "
                                 f"remember my {node.name} as ...")
        raise NovaError("remove takes out an item by its index.",
                        hint=f"For example: {usage}")
    indexes.reverse()
    wheres = [node.name]
    for index in indexes:
        wheres.append(f"{wheres[-1]}[{render_expression(index)}]")
    return node.name, indexes, wheres


class ListCommand:
    """
    Shared by set, add, and remove: work out every expression left to right
    (as written in the line), then change the list.
    """

    def __init__(self, root, indexes, wheres, order):
        self.root = root
        self.key = root.lower()
        self.indexes = indexes    # index trees, outermost first
        self.wheres = wheres      # "grid", "grid[0]", ... for messages
        self.order = order        # every expression tree, in the order it's worked out
        self.has_call = any(contains_call(tree) for tree in order)

    def start(self, variables):
        if self.has_call:
            return self.steps(variables)
        self.apply([evaluate_now(tree, variables) for tree in self.order], variables)

    def steps(self, variables):
        values = []
        for tree in self.order:
            values.append((yield from evaluate_steps(tree, variables)))
        self.apply(values, variables)

    def root_list(self, variables, action):
        """The list stored under the name, owned by the current scope."""
        value = need_list(lookup_variable(self.root, variables), self.wheres[0], action)
        local = variables.maps[0] if hasattr(variables, "maps") else variables
        if self.key not in local:  # a global, seen from inside a function
            value = stored(value)
            local[self.key] = value
        return value

    def descend(self, container, index_values, action):
        """Follow [i][j]... down to the list that will be changed."""
        for step, index in enumerate(index_values):
            position = check_index(container, index, self.wheres[step])
            container = need_list(container.items[position], self.wheres[step + 1], action)
        return container

    def expressions(self):
        return list(self.order)

    def assigned_names(self):
        return {self.key}


class SetCommand(ListCommand):
    """set fruits[1] as "Orange"   (indexes first, then the value)"""

    def apply(self, values, variables):
        *index_values, value = values
        container = self.descend(self.root_list(variables, CHANGE), index_values[:-1], CHANGE)
        position = check_index(container, index_values[-1], self.wheres[len(index_values) - 1])
        container.items[position] = stored(value)


class AddCommand(ListCommand):
    """add "Grape" to fruits   (the value first, then any indexes)"""

    def apply(self, values, variables):
        value, *index_values = values
        container = self.descend(self.root_list(variables, ADD), index_values, ADD)
        container.items.append(stored(value))


class RemoveCommand(ListCommand):
    """remove fruits[1]"""

    def apply(self, index_values, variables):
        container = self.descend(self.root_list(variables, REMOVE), index_values[:-1], REMOVE)
        position = check_index(container, index_values[-1], self.wheres[len(index_values) - 1],
                               removing=True)
        del container.items[position]


def parse_set(args, function_names=()):
    if not args.strip():
        raise NovaError("'set' needs a list item and a new value.", hint=f"For example: {SET_USAGE}")
    tokens = tokenize(args)
    parts = split_at_word(tokens, "as")
    if parts is None:
        raise missing_word_error(tokens, "as", SET_USAGE)
    target_tokens, value_tokens = parts
    if not target_tokens:
        raise NovaError("Say which list item to change before 'as'.", hint=f"For example: {SET_USAGE}")
    if not value_tokens:
        raise NovaError("Say what the new value is after 'as'.", hint=f"For example: {SET_USAGE}")
    root, indexes, wheres = list_target(target_tokens, "set", SET_USAGE, need_index=True)
    return SetCommand(root, indexes, wheres, indexes + [parse_tokens(value_tokens)])


def parse_add(args, function_names=()):
    if not args.strip():
        raise NovaError("'add' needs a value and a list.", hint=f"For example: {ADD_USAGE}")
    tokens = tokenize(args)
    parts = split_at_word(tokens, "to", last=True)
    if parts is None:
        raise missing_word_error(tokens, "to", ADD_USAGE)
    value_tokens, target_tokens = parts
    if not value_tokens:
        raise NovaError("Say what to add before 'to'.", hint=f"For example: {ADD_USAGE}")
    if not target_tokens:
        raise NovaError("Say which list to add it to after 'to'.", hint=f"For example: {ADD_USAGE}")
    value = parse_tokens(value_tokens)
    root, indexes, wheres = list_target(target_tokens, "add", ADD_USAGE, need_index=False)
    return AddCommand(root, indexes, wheres, [value] + indexes)


def parse_remove(args, function_names=()):
    if not args.strip():
        raise NovaError("'remove' needs a list item.", hint=f"For example: {REMOVE_USAGE}")
    tokens = tokenize(args)
    if split_at_word(tokens, "from") is not None:
        raise NovaError("remove takes out an item by its index, not by its value.",
                        hint=f"For example: {REMOVE_USAGE}")
    root, indexes, wheres = list_target(tokens, "remove", REMOVE_USAGE, need_index=True)
    return RemoveCommand(root, indexes, wheres, list(indexes))


# ---------------------------------------------------------------------------
# write / append  (files)
# ---------------------------------------------------------------------------

WRITE_USAGE = 'write "Hello" to "notes.txt"'
APPEND_USAGE = 'append "More text" to "notes.txt"'


class FileCommand:
    """
    write <content> to <path>    replace the file's text (creating the file if needed)
    append <content> to <path>   add to the end of the file (creating it if needed)
    The content is worked out first, then the path, each exactly once; then
    the file is changed.
    """

    def __init__(self, action, content, path):
        self.action = action              # "write" or "append"
        self.order = [content, path]
        self.has_call = contains_call(content) or contains_call(path)

    def start(self, variables):
        if self.has_call:
            return self.steps(variables)
        put_file(evaluate_now(self.order[0], variables), evaluate_now(self.order[1], variables),
                 self.action)

    def steps(self, variables):
        content = yield from evaluate_steps(self.order[0], variables)
        path = yield from evaluate_steps(self.order[1], variables)
        put_file(content, path, self.action)

    def expressions(self):
        return list(self.order)


def parse_file_command(action, usage, args):
    if not args.strip():
        raise NovaError(f"'{action}' needs some text and a file.", hint=f"For example: {usage}")
    tokens = tokenize(args)
    parts = split_at_word(tokens, "to", last=True)
    if parts is None:
        raise missing_word_error(tokens, "to", usage)
    content_tokens, path_tokens = parts
    if not content_tokens:
        raise NovaError(f"Say what to {action} before 'to'.", hint=f"For example: {usage}")
    if not path_tokens:
        raise NovaError("Say which file after 'to'.", hint=f"For example: {usage}")
    return FileCommand(action, parse_tokens(content_tokens), parse_tokens(path_tokens))


def parse_write(args, function_names=()):
    return parse_file_command("write", WRITE_USAGE, args)


def parse_append(args, function_names=()):
    return parse_file_command("append", APPEND_USAGE, args)


# The command table: each command word and the function that parses it.
# Adding a new NOVA command = writing its parser and command, plus one line here.
COMMANDS = {
    "say": parse_say,
    "remember": parse_remember,
    "ask": parse_ask_command,
    "copy": parse_copy,
    "return": parse_return,
    "set": parse_set,
    "add": parse_add,
    "remove": parse_remove,
    "write": parse_write,
    "append": parse_append,
}


def parse_command(line, function_names=()):
    """Parse one command line (done once, during validation). The first word picks the parser."""
    parts = line.split(maxsplit=1)
    return COMMANDS[parts[0].lower()](parts[1] if len(parts) > 1 else "", function_names)
