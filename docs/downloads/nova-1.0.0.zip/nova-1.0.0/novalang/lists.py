"""
List operations shared by expressions (items[0], length of items) and by
the list commands (set, add, remove).

Indexes are zero-based whole numbers. Negative indexes are not supported:
NOVA lists don't count backwards. Every mistake is a friendly NovaError that
names the list, the index, and the valid range.
"""

from .errors import NovaError
from .values import (DIGITS_ONLY, SIMPLE_NUMBER, VALUE_WORDS, describe, format_number, is_list,
                     is_number, is_text)

# How each action is described in "I can only ... a list" messages.
READ = "look up items in"
CHANGE = "change items in"
ADD = "add items to"
REMOVE = "remove items from"


def subject(where):
    """
    How to name the thing an error is about.

    Names and paths are worth showing: fruits, grid[0][0], first(items).
    A value written out in the line is not, because the message would then
    say the same thing twice (but "hi" is the text "hi"), so those become
    "that".
    """
    written_value = (where.startswith('"') or SIMPLE_NUMBER.match(where)
                     or where.lower() in VALUE_WORDS)
    return "that" if written_value else where


def need_list(value, where, action):
    """Make sure a value is a list, or explain what it is instead."""
    if not is_list(value):
        raise NovaError(f"I can only {action} a list, but {subject(where)} is {describe(value)}.",
                        hint='Lists are written with square brackets, like: ["Apple", "Mango"]')
    return value


def check_index(container, index, where, removing=False):
    """Return a valid position in `container`, or raise a friendly error."""
    example = f"Indexes are whole numbers starting at 0, like {where}[0]."
    if not is_number(index):
        hint = example
        if is_text(index) and index[:1] == "0" and DIGITS_ONLY.match(index):
            hint = f"{index} starts with 0, so NOVA keeps it as text. " + example
        raise NovaError(f"A list index must be a number, but it was {describe(index)}.", hint=hint)
    if isinstance(index, float):  # whole floats were already turned into ints
        raise NovaError(f"A list index must be a whole number, but it was {format_number(index)}.",
                        hint=example)
    if index < 0:
        raise NovaError(f"NOVA lists don't count backwards, so an index can't be negative "
                        f"(it was {index}).",
                        hint=f"Indexes start at 0. The last item is at: "
                             f"{where}[length of {where} - 1]")
    size = len(container.items)
    if size == 0:
        if removing:
            raise NovaError(f"{where} is empty, so there's nothing to remove.",
                            hint=f"Check first with: if length of {where} is above 0")
        raise NovaError(f"{where} is empty, so there's no item at index {index}.",
                        hint=f"Put items in it first, like: add \"Apple\" to {where}")
    if index >= size:
        valid = "the only index is 0" if size == 1 else f"the index must be from 0 to {size - 1}"
        raise NovaError(f"{where} has {size} item{'' if size == 1 else 's'}, so {valid}, "
                        f"but it was {index}.",
                        hint=f"Indexes start at 0, so the last item is at {size - 1}.")
    return index


def get_item(container, index, where):
    """items[index] -- reading one item."""
    need_list(container, where, READ)
    return container.items[check_index(container, index, where)]


def length_of(value, where):
    """length of items -- how many items a list holds."""
    if not is_list(value):
        raise NovaError(f"'length of' only works with lists, but {subject(where)} is {describe(value)}.",
                        hint="For example: length of fruits")
    return len(value.items)
